package br.com.caelum.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.com.caelum.jdbc.ConnectionFactory;
import br.com.caelum.jdbc.modelo.Contato;

public class ContatoDao {
	private Connection con = new ConnectionFactory().getConnection();
	private PreparedStatement stmt;

	public void adicionar(Contato contato) throws SQLException {
		String sql = "INSERT INTO contatos (nome,email,endereco,dataNascimento) values(?,?,?,?)";

		try {
			stmt = con.prepareStatement(sql);
			stmt.setString(1, contato.getNome());
			stmt.setString(2, contato.getEmail());
			stmt.setString(3, contato.getEndereco());
			stmt.setDate(4, new java.sql.Date(Calendar.getInstance().getTimeInMillis()));
			stmt.execute();

			stmt.close();
			con.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public List<Contato> getLista() throws SQLException {
			List<Contato> lista = new ArrayList<Contato>();
			String sql = "SELECT * FROM contatos WHERE nome LIKE ('%c%')";
			stmt = con.prepareStatement(sql);
			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				Contato c1 = new Contato();
				c1.setNome(rs.getString("nome"));
				c1.setEmail(rs.getString("email"));
				c1.setEndereco(rs.getString("endereco"));

				Calendar dataCalendar = Calendar.getInstance();				
				dataCalendar.setTime(rs.getDate("dataNascimento"));	
				c1.setDataNasc(dataCalendar);
				
				lista.add(c1);
			}
			
			return lista;
	}
}
