package br.com.caelum.jdbc.modelo;

import java.util.Calendar;

public class Contato {
	private long id;
	private String nome;
	private String email;
	private String endereco;
	private Calendar dataNasc;
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public Calendar getDataNasc() {
		return dataNasc;
	}
	public void setDataNasc(Calendar dataNasc) {
		this.dataNasc = dataNasc;
	}

	
	@Override
	public String toString() {
		return "\n Contato \n [id=" + id + "\n , nome=" + nome + "\n , email=" + email + "\n , endereco=" + endereco + "\n , dataNasc="
				+ dataNasc + "]";
	}
	
	
}
