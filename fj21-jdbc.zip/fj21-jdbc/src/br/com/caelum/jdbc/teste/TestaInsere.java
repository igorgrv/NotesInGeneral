package br.com.caelum.jdbc.teste;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import br.com.caelum.jdbc.dao.ContatoDao;
import br.com.caelum.jdbc.modelo.Contato;

public class TestaInsere {

	public static void main(String[] args) throws SQLException {
		String pattern = "dd-MM-yyyy";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		Contato contato = new Contato();
		ContatoDao dao = new ContatoDao();

		contato.setNome("Caetano");
		contato.setEmail("Caetano@hotmail.com");
		contato.setEndereco("Rua xx");
		contato.setDataNasc(Calendar.getInstance());
//		dao.adicionar(contato);
//		System.out.println("Dados inseridos: " + contato.toString());

		List<Contato> lista = dao.getLista();
		for (Contato con : lista) {
			System.out.println("Nome = " + con.getNome());
			System.out.println("Email = " + con.getEmail());
			System.out.println("Endereco = " + con.getEndereco());
			System.out.println("Data = " + simpleDateFormat.format(con.getDataNasc().getTime()));
			System.out.println("---------------------------------");
		}
	}

}
