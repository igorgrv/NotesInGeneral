package br.com.caelum.agenda.mvc.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.agenda.dao.ContatoDao;
import br.com.caelum.agenda.modelo.Contato;

@SuppressWarnings("serial")
@WebServlet("/adicionaContato")
public class AdicionaContatoServlet extends HttpServlet{

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		Contato c1 = new Contato();
		c1.setNome(req.getParameter("nome"));
		c1.setEmail(req.getParameter("email"));
		c1.setEndereco(req.getParameter("endereco"));

		String dataTexto = req.getParameter("dataNascimento");
		Calendar cal = Calendar.getInstance();

		try {
			Date date = new SimpleDateFormat("dd/MM/yyyy").parse(dataTexto);
			cal.setTime(date);
			c1.setDataNascimento(cal);
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		
		ContatoDao dao = new ContatoDao();
		dao.adiciona(c1);
		
//		Modelo SEM MVC -> utilizado para gerar o HTML		
//		PrintWriter out = resp.getWriter();
//		
//		out.println("<html>");
//		out.println("<body>");
//		out.println("Usuario" + c1.getNome() + "Cadastrado");
//		out.println("</body>");
//		out.println("</html>");
//
//		Modelo COM MVC -> RequestDispacher para encaminhar a uma View (JSP)
		RequestDispatcher rd = req.getRequestDispatcher("/adiciona-contato-view.jsp");
		rd.forward(req, resp);
	}
}
