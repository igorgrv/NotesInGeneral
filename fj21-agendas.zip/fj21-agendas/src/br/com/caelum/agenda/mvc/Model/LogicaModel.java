package br.com.caelum.agenda.mvc.Model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface LogicaModel {
	public String executa(HttpServletRequest resq, HttpServletResponse res) throws Exception;
}
