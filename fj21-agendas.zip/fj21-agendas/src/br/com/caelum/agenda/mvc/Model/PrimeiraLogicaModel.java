package br.com.caelum.agenda.mvc.Model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PrimeiraLogicaModel  implements LogicaModel{
	
	public String executa(HttpServletRequest resq, HttpServletResponse res) {
		System.out.println("Executando a logica...");
		System.out.println("Retornan o nome da página JSP...");
		return "primeira-logica.jsp";
	}
}
