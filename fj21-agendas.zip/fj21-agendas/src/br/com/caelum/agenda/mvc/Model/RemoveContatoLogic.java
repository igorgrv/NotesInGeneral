package br.com.caelum.agenda.mvc.Model;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.agenda.dao.ContatoDao;
import br.com.caelum.agenda.modelo.Contato;

public class RemoveContatoLogic implements LogicaModel {
	
	public String executa(HttpServletRequest req, HttpServletResponse res) {
		//parseLong para converter a String para o long
		long id = Long.parseLong(req.getParameter("id"));
		Contato contato = new Contato();
		contato.setId(id);
		
		//getParameter é para String
		//getAttribute é para objeto
		Connection con = (Connection) req.getAttribute("con");
		ContatoDao dao = new ContatoDao(con);
		dao.exclui(contato);
		
		System.out.println("Excluindo contato... " + contato.getId());
		return "mvc?logica=ListaContatosLogic";
	}
}
