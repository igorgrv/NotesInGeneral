package com.javatechie.redis.respository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.javatechie.redis.entity.Product;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProductDao {

  @Autowired
  private RedisTemplate<Integer, Product> template;

  public Product save(Product product) {

    template.opsForValue().set(product.getId(), product);
    return product;
  }

  // public List<Product> findAll() {
  // return template.opsForValue().values(HASH_KEY);
  // }

  public Product findProductById(int id) {
    log.info("findProductById called with id {}", id);
    return template.opsForValue().get(id);
  }

  public String deleteProduct(int id) {
    // template.opsForValue().getAndDelete(id);
    return "product removed !!";
  }
}
