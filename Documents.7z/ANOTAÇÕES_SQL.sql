-- Funçao: date_format(suaData, formatação desejada) retornará Thursday, 04/Octuber
-- Funcao: format(seuValor, casasDecimais, formatacao)
SELECT format((sum(VAL_OCT_APUR)/100),2,'de_DE'), date_format(DATA_REC, '%W - %d/%M ' ) FROM tb_rec_valores_agendados_yv_historico_bkp WHERE NOM_TRANSPORTADORA LIKE '%PROSEG%' AND DATA_REC LIKE '%2019-10%' GROUP BY DATA_REC;
-- 

