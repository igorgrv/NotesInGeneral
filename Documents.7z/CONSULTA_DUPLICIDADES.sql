-- VERIFICA QUEM DUPLICOU --
SELECT Count(*) AS Expr1, NOME_ARQUIVO, COD_LOCAL, CNPJ_CLI, NOM_CLIENTE ,DATA_REC, COD_OCT, COD_GTV, VAL_OCT_APUR
FROM tb_rec_valores_agendados_yv_bkp
GROUP BY NOME_ARQUIVO, CNPJ_CLI, NOM_CLIENTE, COD_LOCAL, DATA_REC, COD_OCT, COD_GTV, VAL_OCT_APUR
HAVING (((Count(*))>1));


-- 1º passo CRIA A TABELA COM OS ARQUIVOS DUPLICADOS --
create table tb_rec_valores_agendados_yv_backup
select * from tb_rec_valores_agendados_yv_bkp
where NOME_ARQUIVO like '%20200219_05.TX%';

-- VERIFICA TABELA GERADA --
SELECT * FROM tb_rec_valores_agendados_yv_backup;

UPDATE tb_rec_valores_agendados_yv_bkp set id = 0;

SELECT nome_arquivo, Count(NOME_ARQUIVO) from tb_rec_valores_agendados_yv_backup WHERE NOME_ARQUIVO like '%20200325_03%';


-- 2º passo DEIXA A TABELA SEM DUPLICIDADE -- 
SET SQL_SAFE_UPDATES=0;

DELETE a FROM tb_rec_valores_agendados_yv_backup AS a, tb_rec_valores_agendados_yv_backup AS b 
WHERE a.id < b.id
and a.CNPJ_CLI = b.CNPJ_CLI
and a.data_rec = b.data_rec
and a.COD_OCT = b.COD_OCT
and a.COD_GTV = b.COD_GTV
and a.VAL_OCT_APUR = b.VAL_OCT_APUR;


-- 3º passo DEIXA A TABELA YV SEM DUPLICIDADES --
DELETE from tb_rec_valores_agendados_yv_bkp
where NOME_ARQUIVO like '%20200219_05.TX%';

INSERT INTO tb_rec_valores_agendados_yv_bkp (SELECT * FROM tb_rec_valores_agendados_yv_backup);

-- 4º passo LIMPAR A TABELA BKP --
DROP table tb_rec_valores_agendados_yv_backup;



-- DEIXA A TABELA YV SEM DUPLICIDADES segundo modo --
DELETE tb_rec_valores_agendados_yv_bkp.*
FROM tb_rec_valores_agendados_yv_bkp
WHERE NOT EXISTS(SELECT tb_rec_valores_agendados_yv_backup.ID FROM tb_rec_valores_agendados_yv_backup WHERE tb_rec_valores_agendados_yv_backup.id = tb_rec_valores_agendados_yv.id);



-- VERIFICAR USUÁRIOS OU CONSULTAS PENDENTES --
SHOW PROCESSLIST;
KILL 102;

SHOW ENGINE InnoDB STATUS;
SHOW OPEN TABLES WHERE In_use > 0;
SELECT * FROM `information_schema`.`innodb_trx` ORDER BY `trx_started`;
SELECT * FROM `information_schema`.`innodb_locks`;

