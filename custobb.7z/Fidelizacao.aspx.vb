﻿Imports MySql.Data.MySqlClient
Imports System.Data
Imports System.Drawing
Imports System.IO
Partial Class Fidelizacao
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Dim adoconn As New ADODB.Connection
            Dim rs_dados As New ADODB.Recordset
            Dim strSQL As String = ""

            adoconn.Open(Util.conexao)

            Retorna_Cliente()
            Retorna_Grupo()
            Retorna_Especialistas()
            gridClientes.Visible = False
            Pesquisa_Atualizacao()

            If Request("cod") <> "" Then

                strSQL = " SELECT * FROM tb_cliente"
                strSQL = strSQL & " WHERE"
                strSQL = strSQL & " CNPJ_CLI = " & Request("cod")

                rs_dados.Open(strSQL, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

                If Not rs_dados.EOF Then
                    txt_pesquisa_cnpj.Text = rs_dados.Fields("CNPJ_CLI").Value
                End If

                pesquisa_clientes()
            Else
            End If
        End If
    End Sub
    Private Sub Pesquisa_Atualizacao()
        Dim adoconn As New ADODB.Connection
        adoconn.Open(Application("custobb").ToString())

        Dim rs_controle As New ADODB.Recordset
        Dim sql As Object

        sql = "SELECT ARQUIVO_CONV FROM tb_ponto_new order by CODIGO_PONTO desc LIMIT 1"
        rs_controle.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        If Not rs_controle.EOF Then
            referencia.Text = rs_controle.Fields("ARQUIVO_CONV").Value
        Else
            Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
        End If
        rs_controle.Close()

        rs_controle = Nothing
        adoconn.Close()
        adoconn = Nothing

    End Sub

    Private Sub Retorna_Especialistas()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset

        adoconn.Open(Util.conexao)

        cmb_especialista.Items.Add("")

        Dim var_sql1 As Object
        var_sql1 = "SELECT tb_cliente.ESPECIALISTA FROM tb_cliente GROUP BY tb_cliente.ESPECIALISTA HAVING (((tb_cliente.ESPECIALISTA) Is Not Null)) ORDER BY tb_cliente.ESPECIALISTA;"

        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        Do While Not rs_dados.EOF
            cmb_especialista.Items.Add(rs_dados("ESPECIALISTA").Value)
            rs_dados.MoveNext()
        Loop
        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub
    Private Sub Retorna_Grupo()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset

        adoconn.Open(Util.conexao)
        txt_grupo.Items.Add("")

        Dim var_sql1 As Object
        var_sql1 = "SELECT GRUPO FROM tb_cliente WHERE (GRUPO Is Not NULL Or GRUPO <> 0) GROUP BY GRUPO ORDER BY GRUPO"

        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        Do While Not rs_dados.EOF
            txt_grupo.Items.Add(rs_dados("GRUPO").Value)
            rs_dados.MoveNext()
        Loop
        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub

    Private Sub Retorna_Cliente()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset

        adoconn.Open(Util.conexao)
        txt_cliente.Items.Add("")

        Dim var_sql1 As Object
        var_sql1 = "SELECT NOM_CLI FROM tb_cliente GROUP BY NOM_CLI ORDER BY NOM_CLI"

        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        Do While Not rs_dados.EOF
            txt_cliente.Items.Add(rs_dados("NOM_CLI").Value)
            rs_dados.MoveNext()
        Loop
        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub
    Private Sub Retorna_Transportadora()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset

        adoconn.Open(Util.conexao)
        txt_transp_matriz.Items.Add("")

        Dim var_sql1 As Object
        var_sql1 = "SELECT NOME_TRANSPORTADORA FROM tb_transportadora GROUP BY NOME_TRANSPORTADORA"

        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        Do While Not rs_dados.EOF
            txt_transp_matriz.Items.Add(rs_dados("NOME_TRANSPORTADORA").Value)
            rs_dados.MoveNext()
        Loop
        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub

    Protected Sub bt_pesquisa_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_pesquisa.Click

        pesquisa_clientes()
    End Sub

    Protected Sub OnPageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
       gd_clientes.PageIndex = e.NewPageIndex
       pesquisa_clientes()
    End Sub

    Protected Sub Abrir_clinte(ByVal sender As Object, ByVal e As EventArgs)

        Dim row As GridViewRow = CType(CType(sender, LinkButton).Parent.Parent, GridViewRow)

        lbl_id.Text = row.Cells(0).Text
        lbl_nome_user.Text = row.Cells(6).Text
        cmb_perfil_novo.SelectedValue = row.Cells(13).Text
        cmb_inativo_novo.SelectedValue = row.Cells(14).Text

        'mp10.Show()
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "modalAlteraAtivo", "$('#modalAlteraAtivo').modal();", true)
        modalAlteraAtivoModal.Update()

    End Sub
    Protected Sub btnSalvar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSalvar.Click

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        conexaoMySQL.Open()

        Dim sql As String = "UPDATE tb_ponto_new SET PONTO_ATIVO='" & cmb_perfil_novo.SelectedValue & "', OBS_ATIVO = '" & cmb_inativo_novo.SelectedValue & "' WHERE CODIGO_PONTO =" & lbl_id.Text

        Dim cmd As New MySqlCommand(sql, conexaoMySQL)
        Dim result As Integer = cmd.ExecuteNonQuery()

        conexaoMySQL.Close()

        pesquisa_clientes()
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "modalAlteraAtivo", "$('.modal-backdrop').remove();$('body').removeClass('.pace-done modal-open');$('body').removeAttr( 'style' ); ", true) 
        'Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
        'lbl_Aviso.Text = "Lista Atualizada!"

    End Sub
    Protected Sub pesquisa_clientes(Optional ByVal numeroLinhas As Integer = 0)

        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String
        Dim cirterioTarifa As String = ""


        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        conexaoMySQL.Open()


        strSQL = "SET GLOBAL innodb_lock_wait_timeout = 10000"
        daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
        dsMySQL = New DataSet
        daMySQL.Fill(dsMySQL, "Produtos")


        strSQL = ""
        strSQL = strSQL & " SELECT TB_CLIENTE.CODIGO_PONTO, COBRANCA_AUTOM, AG_CLI, CC_CLI, PERIODO_COBRANCA, TARIFA_VARIAVEL, TARIFA_FIXA, DATA_DEBITO, RECOLHIDO_ULT, TARIFA_ULT, TB_CLIENTE.SEGMENTO, "
        strSQL = strSQL & " TB_CLIENTE.ESPECIALISTA, TB_CLIENTE.OBS_ATIVO, TB_CLIENTE.CODIGO_CONVENIO,  TB_CLIENTE.TIPO_CONTRATO, GRUPO, CNPJ_CLI, NOM_CLI,  TB_CLIENTE.COD_LOCAL, "
        strSQL = strSQL & " TB_CLIENTE.NOM_LOCAL, TB_CLIENTE.PONTO_ATIVO, TB_CLIENTE.PRODUTO, TB_CLIENTE.CNPJ_TRANSPORTADORA, TB_CLIENTE.FILIAL_TRANSPORTADORA, "
        strSQL = strSQL & " TB_CLIENTE.DATA_INI_CRED, TB_CLIENTE.DATA_INI_CRED_ONLINE, DATA_ULT_CRED, DATA_ULT_CRED_ONLINE,  "
        strSQL = strSQL & " IF(TB_CLIENTE.DATA_ULT_CRED IS NULL,  "
        strSQL = strSQL & " (IF "
        strSQL = strSQL & " ( "
        strSQL = strSQL & " (weekday(now()) = 0),  "
        strSQL = strSQL & " (DATEDIFF(date_sub(NOW(), INTERVAL 3 DAY), TB_CLIENTE.DATA_ULT_CRED_ONLINE)),  "
        strSQL = strSQL & " (DATEDIFF(date_sub(NOW(), INTERVAL 1 DAY), TB_CLIENTE.DATA_ULT_CRED_ONLINE)) "
        strSQL = strSQL & " ) "
        strSQL = strSQL & " ),  "
        strSQL = strSQL & " (IF "
        strSQL = strSQL & " ( "
        strSQL = strSQL & " (TB_CLIENTE.DATA_ULT_CRED_ONLINE > DATA_ULT_CRED),  "
        strSQL = strSQL & " (IF "
        strSQL = strSQL & " ( "
        strSQL = strSQL & " (weekday(now()) = 0),  "
        strSQL = strSQL & " (DATEDIFF(date_sub(NOW(), INTERVAL 3 DAY), TB_CLIENTE.DATA_ULT_CRED_ONLINE)),  "
        strSQL = strSQL & " (DATEDIFF(date_sub(NOW(), INTERVAL 1 DAY), TB_CLIENTE.DATA_ULT_CRED_ONLINE)) "
        strSQL = strSQL & " ) "
        strSQL = strSQL & " ), "
        strSQL = strSQL & " (IF "
        strSQL = strSQL & " ( "
        strSQL = strSQL & " (weekday(now()) = 0),  "
        strSQL = strSQL & " (DATEDIFF(date_sub(NOW(), INTERVAL 3 DAY), TB_CLIENTE.DATA_ULT_CRED)),  "
        strSQL = strSQL & " (DATEDIFF(date_sub(NOW(), INTERVAL 1 DAY), TB_CLIENTE.DATA_ULT_CRED)) "
        strSQL = strSQL & " ) "
        strSQL = strSQL & " ) "
        strSQL = strSQL & " ) "
        strSQL = strSQL & " ) "
        strSQL = strSQL & " ) AS DIAS_SEM_CRED "
        strSQL = strSQL & " FROM (SELECT tb_tarifa_new.TARIFA_VARIAVEL, tb_tarifa_new.TARIFA_FIXA, tb_tarifa_new.DATA_DEBITO, "
        strSQL = strSQL & " tb_cliente.ESPECIALISTA, tb_cliente.COBRANCA_AUTOM, tb_cliente.AG_CLI, tb_cliente.CC_CLI, tb_cliente.PERIODO_COBRANCA, tb_ponto_new.DATA_ULT_CRED_ONLINE, tb_cliente.GRUPO, tb_cliente.CNPJ_CLI, tb_cliente.NOM_CLI, tb_segmento.SEGMENTO, "
        strSQL = strSQL & " tb_ponto_new.TARIFA_ULT, tb_ponto_new.DATA_ULT_CRED, tb_ponto_new.RECOLHIDO_ULT, tb_ponto_new.OBS_ATIVO, tb_ponto_new.CODIGO_PONTO, tb_ponto_new.PONTO_ATIVO, "
        strSQL = strSQL & " tb_ponto_new.TIPO_CONTRATO, tb_ponto_new.CODIGO_CONVENIO, tb_ponto_new.CODIGO_CLIENTE, tb_ponto_new.COD_LOCAL, tb_ponto_new.NOM_LOCAL, "
        strSQL = strSQL & " tb_ponto_new.PRODUTO, tb_ponto_new.DATA_INI_CRED, tb_ponto_new.DATA_INI_CRED_ONLINE, tb_transportadora.CNPJ_TRANSPORTADORA, "
        strSQL = strSQL & " tb_transportadora.FILIAL_TRANSPORTADORA FROM tb_cliente "
        strSQL = strSQL & " INNER JOIN tb_ponto_new ON tb_ponto_new.CODIGO_CLIENTE = tb_cliente.cnpj_cli "
        strSQL = strSQL & " INNER JOIN tb_transportadora ON tb_ponto_new.PENUMPER_TRA = tb_transportadora.COD_PESSOA_TRANSP "
        strSQL = strSQL & " INNER JOIN tb_segmento ON tb_segmento.SEGMENTO_ID = tb_cliente.SEGMENTO "
        strSQL = strSQL & " INNER JOIN tb_tarifa_new ON tb_tarifa_new.CODIGO_PONTO = tb_ponto_new.CODIGO_PONTO) as TB_CLIENTE "
        strSQL = strSQL & " WHERE NOM_CLI LIKE '%" & Trim(txt_cliente.Text) & "%' AND GRUPO LIKE '%" & Trim(txt_grupo.Text) & "%' "

        If cmb_especialista.SelectedValue <> "" And cmb_especialista.SelectedValue <> "" Then
            strSQL = strSQL & " AND tb_cliente.ESPECIALISTA Like '" & cmb_especialista.SelectedValue & "'"
        End If

        If txt_produto.Text = "RECICLADORA" Then
            strSQL = strSQL & " and TB_CLIENTE.PRODUTO= 'RECICLADORA'"
        ElseIf txt_produto.Text = "COFRE" Then
            strSQL = strSQL & " and (TB_CLIENTE.PRODUTO= 'COFRE' OR TB_CLIENTE.PRODUTO= 'COFRE_D1') "
        ElseIf txt_produto.Text = "RV" Then
            strSQL = strSQL & " and TB_CLIENTE.PRODUTO= 'RV'"
        End If

        If txt_transp_matriz.Text = "BRINKS" Then
            strSQL = strSQL & " and TB_CLIENTE.FILIAL_TRANSPORTADORA LIKE '%BRINK%' "
        ElseIf txt_transp_matriz.Text = "PROSEGUR" Then
            strSQL = strSQL & " and TB_CLIENTE.FILIAL_TRANSPORTADORA LIKE '%PROSEGUR%' "
        ElseIf txt_transp_matriz.Text = "PRESERVE" Then
            strSQL = strSQL & " and TB_CLIENTE.FILIAL_TRANSPORTADORA LIKE '%PRESERVE%' "
        ElseIf txt_transp_matriz.Text = "BLUE ANGELS" Then
            strSQL = strSQL & " and TB_CLIENTE.FILIAL_TRANSPORTADORA LIKE '%BLUE%' "
        ElseIf txt_transp_matriz.Text = "TB FORTE" Then
            strSQL = strSQL & " and TB_CLIENTE.FILIAL_TRANSPORTADORA LIKE '%TBFORTE%' OR  TB_CLIENTE.FILIAL_TRANSPORTADORA LIKE '%TB FORTE%'"
        ElseIf txt_transp_matriz.Text = "TRANSVIP" Then
            strSQL = strSQL & " and TB_CLIENTE.FILIAL_TRANSPORTADORA LIKE '%TRANSVIP%' "
        ElseIf txt_transp_matriz.Text = "PROTEGE" Then
            strSQL = strSQL & " and TB_CLIENTE.FILIAL_TRANSPORTADORA LIKE '%PROTEGE%' "
        ElseIf txt_transp_matriz.Text = "FIDELYS" Then
            strSQL = strSQL & " and TB_CLIENTE.FILIAL_TRANSPORTADORA LIKE '%FIDELYS%' "
        ElseIf txt_transp_matriz.Text = "TECBAN" Then
            strSQL = strSQL & " and TB_CLIENTE.FILIAL_TRANSPORTADORA LIKE '%TECBAN%' "
        End If

        If ck_segmento.Text = "SCIB" Then
            strSQL = strSQL & " and TB_CLIENTE.SEGMENTO = 'SCIB'"
        ElseIf ck_segmento.Text = "CORPORATE" Then
            strSQL = strSQL & " and TB_CLIENTE.SEGMENTO = 'CORPORATE'"
        ElseIf ck_segmento.Text = "VAREJO" Then
            strSQL = strSQL & " and TB_CLIENTE.SEGMENTO = 'VAREJO'"
        End If

        If txt_codigo_ponto.Text <> "" Then
            strSQL = strSQL & " AND  TB_CLIENTE.COD_LOCAL Like '%" & Trim(txt_codigo_ponto.Text) & "%'"
        End If

        If txt_pesquisa_cnpj.Text <> "" Then
            strSQL = strSQL & " and CNPJ_CLI = " & Trim(txt_pesquisa_cnpj.Text)
        End If

        If ck_ponto_ativo.Text = "SIM" Then
            strSQL = strSQL & " and TB_CLIENTE.PONTO_ATIVO = 'S' "
        ElseIf ck_ponto_ativo.Text = "NÃO" Then
            strSQL = strSQL & " and TB_CLIENTE.PONTO_ATIVO = 'N'  "
        End If


        If txt_implantado.Text = "SIM" Then
            strSQL = strSQL & " and (TB_CLIENTE.DATA_INI_CRED is not null OR TB_CLIENTE.DATA_INI_CRED_ONLINE is not null) "
        ElseIf txt_implantado.Text = "NÃO" Then
            strSQL = strSQL & " and TB_CLIENTE.DATA_INI_CRED is null AND TB_CLIENTE.DATA_INI_CRED_ONLINE is null "
        End If

        If txt_contratacao.Text = "BANCO" Then
            strSQL = strSQL & " AND TB_CLIENTE.TIPO_CONTRATO = 'BANCO' "
        ElseIf txt_contratacao.Text = "DIRETO" Then
            strSQL = strSQL & " AND TB_CLIENTE.TIPO_CONTRATO = 'DIRETO' "
        End If

        If ck_possui_online.Checked Then
            strSQL = strSQL & " and TB_CLIENTE.DATA_INI_CRED_ONLINE is not null "
        End If

        strSQL = strSQL & " ORDER BY DIAS_SEM_CRED"

        daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
        dsMySQL = New DataSet
        daMySQL.SelectCommand.CommandTimeout = 99999
        daMySQL.Fill(dsMySQL, "Produtos")
        gd_clientes.DataSource = dsMySQL
        gd_clientes.DataBind()

        conexaoMySQL.Close()
        conexaoMySQL = Nothing

        gridClientes.Visible = True

        Pinta_Grid()
    End Sub
    Protected Sub Pinta_Grid()

        Dim qtd_linhas As Double = 0
        Dim valorRecolhido As Double = 0

        For Each row As GridViewRow In gd_clientes.Rows

            If row.RowType = DataControlRowType.DataRow Then
                qtd_linhas = qtd_linhas + 1
            End If
        Next

        lbl_total_registros.Text = (qtd_linhas)

    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered
    End Sub
    <System.Web.Services.WebMethodAttribute()> <System.Web.Script.Services.ScriptMethodAttribute()> Public Shared Function GetDynamicContent(ByVal contextKey As System.String) As System.String
        '
    End Function
    Protected Sub Gerar_Relatorio_Cobranca()

        pesquisa_clientes()

        'gd_clientes.Columns(0).Visible = True
        'gd_clientes.Columns(1).Visible = False

        Response.Clear()
        Response.ContentEncoding = System.Text.Encoding.UTF8

        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=Relatorio de Clientes.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"

        Using sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)
            Response.Write("<meta http-equiv='content-type' content='application/xhtml+xml; charset=UTF-8' />")

            'ESCONDE COLUNA COM LINK

            gd_clientes.HeaderRow.BackColor = Drawing.Color.White
            For Each cell As TableCell In gd_clientes.HeaderRow.Cells
                cell.BackColor = Drawing.Color.Red
                cell.ForeColor = Drawing.Color.White
            Next
            For Each row As GridViewRow In gd_clientes.Rows
                row.BackColor = Drawing.Color.White
                For Each cell As TableCell In row.Cells
                    If row.RowIndex Mod 2 = 0 Then
                        cell.BackColor = Drawing.Color.White
                    Else
                        cell.BackColor = Drawing.Color.LightGray
                    End If
                    cell.CssClass = "textmode"
                Next
            Next

            gd_clientes.RenderControl(hw)
            'style to format numbers to string
            Dim style As String = "<style> .textmode { } </style>"
            Response.Write(style)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End Using

    End Sub

    Protected Sub bt_gerar_relatorio_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles bt_gerar_relatorio.Click
        Gerar_Relatorio_Cobranca()
    End Sub

End Class
