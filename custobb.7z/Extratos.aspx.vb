﻿Imports MySql.Data.MySqlClient
Imports System.Data
Imports System.Drawing
Imports System.IO

Partial Class Extratos
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Retorna_Grupos()
            select_tabela.Items.Add("relatorio_cobranca_bb_201612")
            select_tabela.Items.Add("relatorio_cobranca_bb_201611")
        End If

    End Sub

    Protected Sub pesquisa_clientes()

        System.Threading.Thread.Sleep(1000)

        Dim conexaoMySQL As New MySqlConnection(Application("custobb").ToString())
        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String
        Dim cirterioTarifa As String = ""

        strSQL = " SELECT * FROM TB_CLIENTE"
        strSQL = strSQL & " where"
        strSQL = strSQL & " (((CNPJ) like '%" & txt_pesquisa.Text & "%') or"
        strSQL = strSQL & " ((RAZAO_SOCIAL) Like '%" & txt_pesquisa.Text & "%')) "

        If cmb_grupo.SelectedValue <> "TODOS" Then
            strSQL = strSQL & " AND GRUPO_COMERCIAL Like '" & cmb_grupo.SelectedValue & "'"
        End If

        daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
        dsMySQL = New DataSet
        daMySQL.Fill(dsMySQL, "Produtos")
        gd_clientes.DataSource = dsMySQL
        gd_clientes.DataBind()

        conexaoMySQL.Open()

        conexaoMySQL.Close()
        conexaoMySQL = Nothing

    End Sub

    Private Sub Retorna_Grupos()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset

        adoconn.Open(Util.conexao)

        cmb_grupo.Items.Add("TODOS")

        Dim var_sql1 As Object
        var_sql1 = "SELECT tb_cliente.GRUPO_COMERCIAL FROM tb_cliente GROUP BY tb_cliente.GRUPO_COMERCIAL ORDER BY tb_cliente.GRUPO_COMERCIAL;"

        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        Do While Not rs_dados.EOF
            cmb_grupo.Items.Add(rs_dados("GRUPO_COMERCIAL").Value)
            rs_dados.MoveNext()
        Loop

        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub


    Protected Sub bt_pesquisa_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_pesquisa.Click

        pesquisa_clientes()

    End Sub


    Protected Sub gd_clientes_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles gd_clientes.SelectedIndexChanged

        Dim ChkBoxHeader As CheckBox = DirectCast(gd_clientes.HeaderRow.FindControl("chkboxSelectAll"), CheckBox)
        For Each row As GridViewRow In gd_clientes.Rows
            Dim ChkBoxRows As CheckBox = DirectCast(row.FindControl("chkEmp"), CheckBox)
            If ChkBoxHeader.Checked = True Then
                ChkBoxRows.Checked = True
            Else
                ChkBoxRows.Checked = False
            End If
        Next

    End Sub

    Protected Sub ExportarArquivoTexto()
        Dim strSQL As String = ""
        Dim criterio As String = ""

        If txt_pesquisa.Text <> "" Then
            criterio = " where"
            criterio = criterio & " (CNPJ like '%" & txt_pesquisa.Text & "%' or razao_social Like '%" & txt_pesquisa.Text & "%')"
        End If

        If cmb_grupo.SelectedValue <> "TODOS" Then
            If criterio = "" Then
                criterio = " where "
            Else
                criterio = criterio & " and "
            End If

            criterio = criterio & " GRUPO Like '" & cmb_grupo.SelectedValue & "'"
        End If

        strSQL = " SELECT * FROM " & select_tabela.SelectedValue & criterio

        Using con As New MySqlConnection(Application("custobb").ToString())
            Using cmd As New MySqlCommand(strSQL)
                Using sda As New MySqlDataAdapter()
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    Using dt As New DataTable()
                        'preenche o datatable
                        sda.Fill(dt)
                        'Constroi os dados do arquivo texto
                        Dim txt As String = String.Empty
                        For Each column As DataColumn In dt.Columns
                            'Incluir um linha de cabecalho
                            txt += column.ColumnName + vbTab
                        Next
                        'Inclui uma nova linha
                        txt += vbCr & vbLf
                        'percorre o datatable
                        For Each row As DataRow In dt.Rows

                            For Each column As DataColumn In dt.Columns
                                'Inclui as linhas de dados
                                txt += row(column.ColumnName).ToString() + vbTab
                            Next
                            'Nova linha
                            txt += vbCr & vbLf
                        Next
                        'Faz o Download do arquivo texto
                        Response.Clear()
                        Response.Buffer = True
                        Response.AddHeader("content-disposition", "attachment;filename=Relatorio.xls")
                        Response.Charset = ""
                        Response.ContentType = "application/vnd.ms-excel"
                        Response.Output.Write(txt)
                        Response.Flush()
                        Response.End()
                    End Using
                End Using
            End Using
        End Using

    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered
    End Sub

    Protected Sub bt_gerar_relatorio_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles bt_gerar_relatorio.Click
        ExportarArquivoTexto()

    End Sub

End Class
