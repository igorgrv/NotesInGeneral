﻿Imports MySql.Data.MySqlClient
Imports System.Data
Imports System.Drawing
Imports System.IO

Partial Class Default2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If Session("perfil") = "Admin" Then
                bt_gerar_lista_financa.Visible = True
            End If
            Retorna_Grupo()
            Retorna_Especialistas()
            carrega_combo_mes_ref()
            carrega_combo_mes_hist()
            Imageaviso.Visible = False
            gridClientes.Visible = False
        End If

    End Sub
    Protected Sub bt_pesquisar_ponto_2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_pesquisar_ponto_2.Click
        pesquisa_lista_debito_historico()
    End Sub
    Private Sub Retorna_Especialistas()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset

        adoconn.Open(Util.conexao)

        cmb_especialista.Items.Add("")

        Dim var_sql1 As Object
        var_sql1 = "SELECT tb_cliente.ESPECIALISTA FROM tb_cliente GROUP BY tb_cliente.ESPECIALISTA HAVING (((tb_cliente.ESPECIALISTA) Is Not Null)) ORDER BY tb_cliente.ESPECIALISTA;"

        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        Do While Not rs_dados.EOF
            cmb_especialista.Items.Add(rs_dados("ESPECIALISTA").Value)
            rs_dados.MoveNext()
        Loop
        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub
    Private Sub Retorna_Grupo()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset

        adoconn.Open(Util.conexao)
        txt_grupo.Items.Add("")

        Dim var_sql1 As Object
        var_sql1 = "SELECT GRUPO FROM tb_cliente WHERE (GRUPO Is Not NULL Or GRUPO <> 0) GROUP BY GRUPO ORDER BY GRUPO"

        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        Do While Not rs_dados.EOF
            txt_grupo.Items.Add(rs_dados("GRUPO").Value)
            rs_dados.MoveNext()
        Loop
        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub
    Protected Sub carrega_combo_mes_ref()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset
        adoconn.Open(Application("custobb").ToString())

        Dim var_sql1 As Object
        var_sql1 = "SELECT MES_REFERENCIA FROM tb_cobranca_bb_bkp ORDER BY COBRANCAID DESC;"
        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        If Not rs_dados.EOF Then
            lbl_mes_atual.Text = rs_dados("MES_REFERENCIA").Value
            lbl_mes_atual_finan.Text = rs_dados("MES_REFERENCIA").Value
        End If

        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub
    Protected Sub carrega_combo_mes_hist()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset
        adoconn.Open(Util.conexao)

        Dim var_sql2 As Object
        var_sql2 = "SELECT referencia, mesAno FROM tb_cobranca_bb_referencia ORDER BY referenciaid desc limit 1,100;"

        rs_dados.Open(var_sql2, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        Do While Not rs_dados.EOF
            cmb_referencia.Items.Add(rs_dados.Fields("mesAno").Value)
            rs_dados.MoveNext()
        Loop

        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered
    End Sub
    <System.Web.Services.WebMethodAttribute()> <System.Web.Script.Services.ScriptMethodAttribute()> Public Shared Function GetDynamicContent(ByVal contextKey As System.String) As System.String

    End Function
    Protected Sub Gerar_Relatorio_Lista_Debito_Agrupado()

        Response.Clear()
        Response.ContentEncoding = System.Text.Encoding.UTF8

        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=Relatorio de Cobranca.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"

        Using sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)
            Response.Write("<meta http-equiv='content-type' content='application/xhtml+xml; charset=UTF-8' />")

            'To Export all pages
            gd_clientes_agrupado.AllowPaging = False

            'pesquisa_clientes()

            gd_clientes_agrupado.HeaderRow.BackColor = Drawing.Color.White
            For Each cell As TableCell In gd_clientes_agrupado.HeaderRow.Cells
                cell.BackColor = Drawing.Color.Red
                cell.ForeColor = Drawing.Color.White
            Next
            For Each row As GridViewRow In gd_clientes_agrupado.Rows
                row.BackColor = Drawing.Color.White
                For Each cell As TableCell In row.Cells
                    If row.RowIndex Mod 2 = 0 Then
                        cell.BackColor = Drawing.Color.White
                    Else
                        cell.BackColor = Drawing.Color.LightGray
                    End If
                    cell.CssClass = "textmode"
                Next
            Next

            gd_clientes_agrupado.RenderControl(hw)
            'style to format numbers to string
            Dim style As String = "<style> .textmode { } </style>"
            Response.Write(style)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End Using

    End Sub
    Protected Sub Gerar_Relatorio_Lista_Debito()

        Response.Clear()
        Response.ContentEncoding = System.Text.Encoding.UTF8

        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=Relatorio de Cobranca.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"

        Using sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)
            Response.Write("<meta http-equiv='content-type' content='application/xhtml+xml; charset=UTF-8' />")

            'To Export all pages
            gd_lista_debito.AllowPaging = False

            'pesquisa_clientes()

            gd_lista_debito.HeaderRow.BackColor = Drawing.Color.White
            For Each cell As TableCell In gd_lista_debito.HeaderRow.Cells
                cell.BackColor = Drawing.Color.Red
                cell.ForeColor = Drawing.Color.White
            Next
            For Each row As GridViewRow In gd_lista_debito.Rows
                row.BackColor = Drawing.Color.White
                For Each cell As TableCell In row.Cells
                    If row.RowIndex Mod 2 = 0 Then
                        cell.BackColor = Drawing.Color.White
                    Else
                        cell.BackColor = Drawing.Color.LightGray
                    End If
                    cell.CssClass = "textmode"
                Next
            Next

            gd_lista_debito.RenderControl(hw)
            'style to format numbers to string
            Dim style As String = "<style> .textmode { } </style>"
            Response.Write(style)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End Using

    End Sub
    Protected Sub Gerar_Relatorio_Lista_Financa()

        Response.Clear()
        Response.ContentEncoding = System.Text.Encoding.UTF8

        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=Relatorio de Cobranca.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"

        Using sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)
            Response.Write("<meta http-equiv='content-type' content='application/xhtml+xml; charset=UTF-8' />")

            'To Export all pages
            gd_lista_financa.AllowPaging = False

            'pesquisa_clientes()

            gd_lista_financa.HeaderRow.BackColor = Drawing.Color.White
            For Each cell As TableCell In gd_lista_financa.HeaderRow.Cells
                cell.BackColor = Drawing.Color.Red
                cell.ForeColor = Drawing.Color.White
            Next
            For Each row As GridViewRow In gd_lista_financa.Rows
                row.BackColor = Drawing.Color.White
                For Each cell As TableCell In row.Cells
                    If row.RowIndex Mod 2 = 0 Then
                        cell.BackColor = Drawing.Color.White
                    Else
                        cell.BackColor = Drawing.Color.LightGray
                    End If
                    cell.CssClass = "textmode"
                Next
            Next

            gd_lista_financa.RenderControl(hw)
            'style to format numbers to string
            Dim style As String = "<style> .textmode { } </style>"
            Response.Write(style)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End Using

    End Sub

    Protected Sub pesquisa_lista_debito()

        gd_lista_financa.Visible = False
        gd_lista_debito.Visible = False
        gd_clientes_agrupado.Visible = False
        gridClientes.Visible = True

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String = ""

        strSQL = strSQL & "SELECT tb_segmento.SEGMENTO, tb_cliente.GRUPO, tb_cliente.ESPECIALISTA, tb_ponto_new.CODIGO_CONVENIO, tb_cliente.CNPJ_CLI, tb_cliente.NOM_CLI, tb_cliente.AG_CLI, tb_cliente.CC_CLI, "
        strSQL = strSQL & "tb_ponto_new.COD_LOCAL, tb_ponto_new.NOM_LOCAL, tb_ponto_new.PRODUTO, tb_ponto_new.TIPO_CONTRATO, tb_cliente.PERIODO_COBRANCA, tb_cliente.COBRANCA_AUTOM, "
        strSQL = strSQL & "tb_cobranca_bb_bkp.VALOR_RECOLHIDO, tb_cobranca_bb_bkp.CUSTO_SPREAD, tb_cobranca_bb_bkp.CUSTO_SPREAD_FIXO, "
        strSQL = strSQL & "tb_cobranca_bb_bkp.COBRANCA_PERCENTUAL, tb_cobranca_bb_bkp.MES_REFERENCIA, tb_cobranca_bb_bkp.VALOR_BB_FINAL, tb_cobranca_bb_bkp.DATA_TARIFA, tb_cobranca_bb_bkp.OBSERVACAO, "
        strSQL = strSQL & "tb_cobranca_bb_bkp.RECOLHIDO_DESPESA, tb_cobranca_bb_bkp.VALOR_DESPESA, tb_cobranca_bb_bkp.RESULTADO "
        strSQL = strSQL & "FROM tb_cobranca_bb_bkp "
        strSQL = strSQL & "INNER Join tb_cliente ON tb_cliente.CNPJ_CLI = tb_cobranca_bb_bkp.CNPJ "
        strSQL = strSQL & "INNER Join tb_segmento ON tb_segmento.SEGMENTO_ID = tb_cliente.SEGMENTO "
        strSQL = strSQL & "INNER Join tb_ponto_new ON tb_cobranca_bb_bkp.CODIGO_PONTO = tb_ponto_new.CODIGO_PONTO "
        strSQL = strSQL & "WHERE GRUPO LIKE '%" & Trim(txt_grupo.Text) & "%' AND MES_REFERENCIA = '" & lbl_mes_atual.Text & "'"

        If ck_agrupar.Checked Then
            strSQL = ""
            strSQL = strSQL & "SELECT tb_segmento.SEGMENTO, tb_cliente.GRUPO, tb_cliente.ESPECIALISTA, tb_ponto_new.CODIGO_CONVENIO, tb_cliente.CNPJ_CLI, tb_cliente.NOM_CLI, tb_cliente.AG_CLI, tb_cliente.CC_CLI, "
            strSQL = strSQL & "tb_ponto_new.PRODUTO, tb_ponto_new.TIPO_CONTRATO, tb_cliente.PERIODO_COBRANCA, tb_cliente.COBRANCA_AUTOM, "
            strSQL = strSQL & "sum(tb_cobranca_bb_bkp.VALOR_RECOLHIDO) AS VALOR_RECOLHIDO, sum(tb_cobranca_bb_bkp.CUSTO_SPREAD_FIXO) AS CUSTO_SPREAD_FIXO, "
            strSQL = strSQL & "sum(tb_cobranca_bb_bkp.COBRANCA_PERCENTUAL) AS COBRANCA_PERCENTUAL, tb_cobranca_bb_bkp.MES_REFERENCIA, sum(tb_cobranca_bb_bkp.VALOR_BB_FINAL) AS VALOR_BB_FINAL, "
            strSQL = strSQL & "sum(tb_cobranca_bb_bkp.RECOLHIDO_DESPESA) AS RECOLHIDO_DESPESA, sum(tb_cobranca_bb_bkp.VALOR_DESPESA) AS VALOR_DESPESA, sum(tb_cobranca_bb_bkp.RESULTADO) AS RESULTADO "
            strSQL = strSQL & "FROM tb_cobranca_bb_bkp "
            strSQL = strSQL & "INNER Join tb_cliente ON tb_cliente.CNPJ_CLI = tb_cobranca_bb_bkp.CNPJ "
            strSQL = strSQL & "INNER Join tb_segmento ON tb_segmento.SEGMENTO_ID = tb_cliente.SEGMENTO "
            strSQL = strSQL & "INNER Join tb_ponto_new ON tb_cobranca_bb_bkp.CODIGO_PONTO = tb_ponto_new.CODIGO_PONTO "
            strSQL = strSQL & "WHERE GRUPO LIKE '%" & Trim(txt_grupo.Text) & "%' AND MES_REFERENCIA = '" & lbl_mes_atual.Text & "'"
        End If

        If cmb_especialista.SelectedValue <> "" And cmb_especialista.SelectedValue <> "" Then
            strSQL = strSQL & " AND tb_cliente.ESPECIALISTA Like '" & cmb_especialista.SelectedValue & "'"
        End If

        If txt_produto.Text = "RECICLADORA" Then
            strSQL = strSQL & " and tb_ponto_new.PRODUTO= 'RECICLADORA'"
        ElseIf txt_produto.Text = "COFRE" Then
            strSQL = strSQL & " and (tb_ponto_new.PRODUTO= 'COFRE' OR tb_ponto_new.PRODUTO= 'COFRE_D1') "
        ElseIf txt_produto.Text = "RV" Then
            strSQL = strSQL & " and tb_ponto_new.PRODUTO= 'RV'"
        End If

        If ck_segmento.Text = "SCIB" Then
            strSQL = strSQL & " and tb_segmento.SEGMENTO = 'SCIB'"
        ElseIf ck_segmento.Text = "CORPORATE" Then
            strSQL = strSQL & " and tb_segmento.SEGMENTO = 'CORPORATE'"
        ElseIf ck_segmento.Text = "VAREJO" Then
            strSQL = strSQL & " and tb_segmento.SEGMENTO = 'VAREJO'"
        End If

        If txt_contratacao.Text = "BANCO" Then
            strSQL = strSQL & " AND tb_ponto_new.TIPO_CONTRATO = 'BANCO' "
        ElseIf txt_contratacao.Text = "DIRETO" Then
            strSQL = strSQL & " AND tb_ponto_new.TIPO_CONTRATO = 'DIRETO' "
        End If

        If cmb_tarifa.Text = "SIM" Then
            strSQL = strSQL & " AND tb_cobranca_bb_bkp.VALOR_BB_FINAL > 0 "
        ElseIf cmb_tarifa.Text = "NÃO" Then
            strSQL = strSQL & " AND tb_cobranca_bb_bkp.VALOR_BB_FINAL = 0 "
        End If

        If ck_agrupar.Checked Then
            strSQL = strSQL & "GROUP BY tb_ponto_new.CODIGO_CONVENIO "
        End If

        strSQL = strSQL & " ORDER BY NOM_CLI"

        If ck_agrupar.Checked Then
            daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
            dsMySQL = New DataSet
            daMySQL.Fill(dsMySQL, "Produtos")
            gd_clientes_agrupado.DataSource = dsMySQL
            gd_clientes_agrupado.DataBind()
            gd_lista_debito.Visible = False
            gd_clientes_agrupado.Visible = True
        Else
            daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
            dsMySQL = New DataSet
            daMySQL.Fill(dsMySQL, "Produtos")
            gd_lista_debito.DataSource = dsMySQL
            gd_lista_debito.DataBind()
            gd_lista_debito.Visible = True
            gd_clientes_agrupado.Visible = False
        End If

        If gd_lista_debito.Rows.Count = 0 And gd_clientes_agrupado.Rows.Count = 0 Then
            Imageaviso.Visible = True
        Else
            Imageaviso.Visible = False
        End If

        Pinta_Grid()
        'ScriptManager.RegisterStartupScript(Page, Page.GetType(), "collapseTwo", "$('#collapseTwo').collapse('show');", True)

    End Sub
    Protected Sub pesquisa_lista_debito_historico()

        gd_lista_financa.Visible = False
        gd_lista_debito.Visible = False
        gd_clientes_agrupado.Visible = False
        gridClientes.Visible = True

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String = ""

        strSQL = strSQL & "SELECT tb_segmento.SEGMENTO, tb_cliente.GRUPO, tb_cliente.ESPECIALISTA, tb_ponto_new.CODIGO_CONVENIO, tb_cliente.CNPJ_CLI, tb_cliente.NOM_CLI, tb_cliente.AG_CLI, tb_cliente.CC_CLI, "
        strSQL = strSQL & "tb_ponto_new.COD_LOCAL, tb_ponto_new.NOM_LOCAL, tb_ponto_new.PRODUTO, tb_ponto_new.TIPO_CONTRATO, tb_cliente.PERIODO_COBRANCA, tb_cliente.COBRANCA_AUTOM, "
        strSQL = strSQL & "tb_cobranca_bb_historico.VALOR_RECOLHIDO, tb_cobranca_bb_historico.CUSTO_SPREAD, tb_cobranca_bb_historico.CUSTO_SPREAD_FIXO, "
        strSQL = strSQL & "tb_cobranca_bb_historico.COBRANCA_PERCENTUAL, tb_cobranca_bb_historico.MES_REFERENCIA, tb_cobranca_bb_historico.VALOR_BB_FINAL, tb_cobranca_bb_historico.DATA_TARIFA, tb_cobranca_bb_historico.OBSERVACAO, "
        strSQL = strSQL & "tb_cobranca_bb_historico.RECOLHIDO_DESPESA, tb_cobranca_bb_historico.VALOR_DESPESA, tb_cobranca_bb_historico.RESULTADO "
        strSQL = strSQL & "From tb_cobranca_bb_historico "
        strSQL = strSQL & "INNER Join tb_cliente ON tb_cliente.CNPJ_CLI = tb_cobranca_bb_historico.CNPJ "
        strSQL = strSQL & "INNER Join tb_segmento ON tb_segmento.SEGMENTO_ID = tb_cliente.SEGMENTO "
        strSQL = strSQL & "INNER Join tb_ponto_new ON tb_cobranca_bb_historico.CODIGO_PONTO = tb_ponto_new.CODIGO_PONTO "
        strSQL = strSQL & "WHERE GRUPO LIKE '%" & Trim(txt_grupo.Text) & "%' AND MES_REFERENCIA = '" & cmb_referencia.Text & "'"

        If ck_agrupar.Checked Then
            strSQL = ""
            strSQL = strSQL & "SELECT tb_segmento.SEGMENTO, tb_cliente.GRUPO, tb_cliente.ESPECIALISTA, tb_ponto_new.CODIGO_CONVENIO, tb_cliente.CNPJ_CLI, tb_cliente.NOM_CLI, tb_cliente.AG_CLI, tb_cliente.CC_CLI, "
            strSQL = strSQL & "tb_ponto_new.PRODUTO, tb_ponto_new.TIPO_CONTRATO, tb_cliente.PERIODO_COBRANCA, tb_cliente.COBRANCA_AUTOM, "
            strSQL = strSQL & "sum(tb_cobranca_bb_historico.VALOR_RECOLHIDO) AS VALOR_RECOLHIDO, sum(tb_cobranca_bb_historico.CUSTO_SPREAD_FIXO) AS CUSTO_SPREAD_FIXO, "
            strSQL = strSQL & "sum(tb_cobranca_bb_historico.COBRANCA_PERCENTUAL) AS COBRANCA_PERCENTUAL, tb_cobranca_bb_historico.MES_REFERENCIA, sum(tb_cobranca_bb_historico.VALOR_BB_FINAL) AS VALOR_BB_FINAL, "
            strSQL = strSQL & "sum(tb_cobranca_bb_historico.RECOLHIDO_DESPESA) AS RECOLHIDO_DESPESA, sum(tb_cobranca_bb_historico.VALOR_DESPESA) AS VALOR_DESPESA, sum(tb_cobranca_bb_historico.RESULTADO) AS RESULTADO "
            strSQL = strSQL & "From tb_cobranca_bb_historico "
            strSQL = strSQL & "INNER Join tb_cliente ON tb_cliente.CNPJ_CLI = tb_cobranca_bb_historico.CNPJ "
            strSQL = strSQL & "INNER Join tb_segmento ON tb_segmento.SEGMENTO_ID = tb_cliente.SEGMENTO "
            strSQL = strSQL & "INNER Join tb_ponto_new ON tb_cobranca_bb_historico.CODIGO_PONTO = tb_ponto_new.CODIGO_PONTO "
            strSQL = strSQL & "WHERE GRUPO LIKE '%" & Trim(txt_grupo.Text) & "%' AND MES_REFERENCIA = '" & cmb_referencia.Text & "'"
        End If

        If cmb_especialista.SelectedValue <> "" And cmb_especialista.SelectedValue <> "" Then
            strSQL = strSQL & " AND tb_cliente.ESPECIALISTA Like '" & cmb_especialista.SelectedValue & "'"
        End If

        If txt_produto.Text = "RECICLADORA" Then
            strSQL = strSQL & " and tb_ponto_new.PRODUTO= 'RECICLADORA'"
        ElseIf txt_produto.Text = "COFRE" Then
            strSQL = strSQL & " and (tb_ponto_new.PRODUTO= 'COFRE' OR tb_ponto_new.PRODUTO= 'COFRE_D1') "
        ElseIf txt_produto.Text = "RV" Then
            strSQL = strSQL & " and tb_ponto_new.PRODUTO= 'RV'"
        End If

        If ck_segmento.Text = "SCIB" Then
            strSQL = strSQL & " and tb_segmento.SEGMENTO = 'SCIB'"
        ElseIf ck_segmento.Text = "CORPORATE" Then
            strSQL = strSQL & " and tb_segmento.SEGMENTO = 'CORPORATE'"
        ElseIf ck_segmento.Text = "VAREJO" Then
            strSQL = strSQL & " and tb_segmento.SEGMENTO = 'VAREJO'"
        End If

        If txt_contratacao.Text = "BANCO" Then
            strSQL = strSQL & " AND tb_ponto_new.TIPO_CONTRATO = 'BANCO' "
        ElseIf txt_contratacao.Text = "DIRETO" Then
            strSQL = strSQL & " AND tb_ponto_new.TIPO_CONTRATO = 'DIRETO' "
        End If

        If cmb_tarifa.Text = "SIM" Then
            strSQL = strSQL & " AND tb_cobranca_bb_bkp.VALOR_BB_FINAL > 0 "
        ElseIf cmb_tarifa.Text = "NÃO" Then
            strSQL = strSQL & " AND tb_cobranca_bb_bkp.VALOR_BB_FINAL = 0 "
        End If

        If ck_agrupar.Checked Then
            strSQL = strSQL & "GROUP BY tb_ponto_new.CODIGO_CONVENIO "
        End If

        strSQL = strSQL & " ORDER BY NOM_CLI"

        If ck_agrupar.Checked Then
            daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
            dsMySQL = New DataSet
            daMySQL.SelectCommand.CommandTimeout = 99999
            daMySQL.Fill(dsMySQL, "Produtos")
            gd_clientes_agrupado.DataSource = dsMySQL
            gd_clientes_agrupado.DataBind()
            gd_lista_debito.Visible = False
            gd_clientes_agrupado.Visible = True
        Else
            daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
            dsMySQL = New DataSet
            daMySQL.SelectCommand.CommandTimeout = 99999
            daMySQL.Fill(dsMySQL, "Produtos")
            gd_lista_debito.DataSource = dsMySQL
            gd_lista_debito.DataBind()
            gd_lista_debito.Visible = True
            gd_clientes_agrupado.Visible = False
        End If

        If gd_lista_debito.Rows.Count = 0 And gd_clientes_agrupado.Rows.Count = 0 Then
            Imageaviso.Visible = True
        Else
            Imageaviso.Visible = False
        End If

        Pinta_Grid()
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "collapseTwo", "$('#collapseTwo').collapse('show');", True)

    End Sub
    Sub Pinta_Grid()

        Dim qtd_linhas As Double = 0
        Dim valorTarifa As Double = 0
        Dim valorDeposito As Double = 0
        Dim valorDespesa As Double = 0
        Dim valorResultado As Double = 0

        If ck_agrupar.Checked Then
            For Each row As GridViewRow In gd_clientes_agrupado.Rows
                If row.RowType = DataControlRowType.DataRow Then
                    If IsNumeric(row.Cells(15).Text) Then
                        valorTarifa = valorTarifa + CDbl(row.Cells(15).Text)
                    End If

                    If IsNumeric(row.Cells(12).Text) Then
                        valorDeposito = valorDeposito + CDbl(row.Cells(12).Text)
                    End If

                    If IsNumeric(row.Cells(17).Text) Then
                        valorDespesa = valorDespesa + CDbl(row.Cells(17).Text)
                    End If

                    If IsNumeric(row.Cells(18).Text) Then
                        valorResultado = valorResultado + CDbl(row.Cells(18).Text)
                    End If

                    qtd_linhas = qtd_linhas + 1

                    If row.Cells(15).Text = "R$ 0,00" Then
                        row.Cells(0).BackColor = Color.Yellow
                        row.Cells(1).BackColor = Color.Yellow
                        row.Cells(2).BackColor = Color.Yellow
                        row.Cells(3).BackColor = Color.Yellow
                        row.Cells(4).BackColor = Color.Yellow
                        row.Cells(5).BackColor = Color.Yellow
                        row.Cells(6).BackColor = Color.Yellow
                        row.Cells(7).BackColor = Color.Yellow
                        row.Cells(8).BackColor = Color.Yellow
                        row.Cells(9).BackColor = Color.Yellow
                        row.Cells(10).BackColor = Color.Yellow
                        row.Cells(11).BackColor = Color.Yellow
                        row.Cells(12).BackColor = Color.Yellow
                        row.Cells(13).BackColor = Color.Yellow
                        row.Cells(14).BackColor = Color.Yellow
                        row.Cells(15).BackColor = Color.Yellow
                        row.Cells(16).BackColor = Color.Yellow
                        row.Cells(17).BackColor = Color.Yellow
                        row.Cells(18).BackColor = Color.Yellow
                        row.Cells(19).BackColor = Color.Yellow

                        If row.Cells(17).Text = "" Then
                            row.Cells(0).BackColor = Color.Yellow
                            row.Cells(1).BackColor = Color.Yellow
                            row.Cells(2).BackColor = Color.Yellow
                            row.Cells(3).BackColor = Color.Yellow
                            row.Cells(4).BackColor = Color.Yellow
                            row.Cells(5).BackColor = Color.Yellow
                            row.Cells(6).BackColor = Color.Yellow
                            row.Cells(7).BackColor = Color.Yellow
                            row.Cells(8).BackColor = Color.Yellow
                            row.Cells(9).BackColor = Color.Yellow
                            row.Cells(10).BackColor = Color.Yellow
                            row.Cells(11).BackColor = Color.Yellow
                            row.Cells(12).BackColor = Color.Yellow
                            row.Cells(13).BackColor = Color.Yellow
                            row.Cells(14).BackColor = Color.Yellow
                            row.Cells(15).BackColor = Color.Yellow
                            row.Cells(16).BackColor = Color.Yellow
                            row.Cells(17).BackColor = Color.Yellow
                            row.Cells(18).BackColor = Color.Yellow
                            row.Cells(19).BackColor = Color.Yellow
                        End If
                    End If
                End If
            Next
        Else
            For Each row As GridViewRow In gd_lista_debito.Rows

                If row.RowType = DataControlRowType.DataRow Then

                    If IsNumeric(row.Cells(18).Text) Then
                        valorTarifa = valorTarifa + CDbl(row.Cells(18).Text)
                    End If

                    If IsNumeric(row.Cells(14).Text) Then
                        valorDeposito = valorDeposito + CDbl(row.Cells(14).Text)
                    End If

                    If IsNumeric(row.Cells(22).Text) Then
                        valorDespesa = valorDespesa + CDbl(row.Cells(22).Text)
                    End If

                    If IsNumeric(row.Cells(23).Text) Then
                        valorResultado = valorResultado + CDbl(row.Cells(23).Text)
                    End If

                    qtd_linhas = qtd_linhas + 1

                    If row.Cells(18).Text = "R$ 0,00" Then
                        row.Cells(0).BackColor = Color.Yellow
                        row.Cells(1).BackColor = Color.Yellow
                        row.Cells(2).BackColor = Color.Yellow
                        row.Cells(3).BackColor = Color.Yellow
                        row.Cells(4).BackColor = Color.Yellow
                        row.Cells(5).BackColor = Color.Yellow
                        row.Cells(6).BackColor = Color.Yellow
                        row.Cells(7).BackColor = Color.Yellow
                        row.Cells(8).BackColor = Color.Yellow
                        row.Cells(9).BackColor = Color.Yellow
                        row.Cells(10).BackColor = Color.Yellow
                        row.Cells(11).BackColor = Color.Yellow
                        row.Cells(12).BackColor = Color.Yellow
                        row.Cells(13).BackColor = Color.Yellow
                        row.Cells(14).BackColor = Color.Yellow
                        row.Cells(15).BackColor = Color.Yellow
                        row.Cells(16).BackColor = Color.Yellow
                        row.Cells(17).BackColor = Color.Yellow
                        row.Cells(18).BackColor = Color.Yellow
                        row.Cells(19).BackColor = Color.Yellow
                        row.Cells(20).BackColor = Color.Yellow
                        row.Cells(21).BackColor = Color.Yellow
                        row.Cells(22).BackColor = Color.Yellow
                        row.Cells(23).BackColor = Color.Yellow
                        row.Cells(24).BackColor = Color.Yellow

                        If row.Cells(18).Text = "" Then
                            row.Cells(0).BackColor = Color.Yellow
                            row.Cells(1).BackColor = Color.Yellow
                            row.Cells(2).BackColor = Color.Yellow
                            row.Cells(3).BackColor = Color.Yellow
                            row.Cells(4).BackColor = Color.Yellow
                            row.Cells(5).BackColor = Color.Yellow
                            row.Cells(6).BackColor = Color.Yellow
                            row.Cells(7).BackColor = Color.Yellow
                            row.Cells(8).BackColor = Color.Yellow
                            row.Cells(9).BackColor = Color.Yellow
                            row.Cells(10).BackColor = Color.Yellow
                            row.Cells(11).BackColor = Color.Yellow
                            row.Cells(12).BackColor = Color.Yellow
                            row.Cells(13).BackColor = Color.Yellow
                            row.Cells(14).BackColor = Color.Yellow
                            row.Cells(15).BackColor = Color.Yellow
                            row.Cells(16).BackColor = Color.Yellow
                            row.Cells(17).BackColor = Color.Yellow
                            row.Cells(18).BackColor = Color.Yellow
                            row.Cells(19).BackColor = Color.Yellow
                            row.Cells(20).BackColor = Color.Yellow
                            row.Cells(21).BackColor = Color.Yellow
                            row.Cells(22).BackColor = Color.Yellow
                            row.Cells(23).BackColor = Color.Yellow
                            row.Cells(24).BackColor = Color.Yellow
                        End If
                    End If
                End If
            Next
        End If

        lbl_numero_pontos.Text = qtd_linhas
        lbl_total_tarifa.Text = FormatCurrency(valorTarifa)
        lbl_total_recolhido.Text = FormatCurrency(valorDeposito)
        lbl_total_despesa.Text = FormatCurrency(valorDespesa)
        lbl_total_resultado.Text = FormatCurrency(valorResultado)

    End Sub
    Protected Sub pesquisa_lista_financa()


        gd_lista_debito.Visible = False
        gd_clientes_agrupado.Visible = False
        gd_lista_financa.Visible = True
        gridClientes.Visible = True

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String = ""

        strSQL = strSQL & " SELECT *"
        strSQL = strSQL & " FROM tb_cobranca_bb_financas"
        strSQL = strSQL & " WHERE MES_REFERENCIA = '" & lbl_mes_atual.Text & "'"
        strSQL = strSQL & " GROUP BY CODIGO_PONTO"
        strSQL = strSQL & " ORDER BY CNPJ"

        daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
        dsMySQL = New DataSet
        daMySQL.SelectCommand.CommandTimeout = 99999
        daMySQL.Fill(dsMySQL, "Produtos")
        gd_lista_financa.DataSource = dsMySQL
        gd_lista_financa.DataBind()
        gd_lista_financa.Visible = True

        If gd_lista_financa.Rows.Count = 0 Then
            Imageaviso.Visible = True
        Else
            Imageaviso.Visible = False
        End If

    End Sub

    Protected Sub bt_gerar_lista_debito_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_gerar_lista_debito.Click
        pesquisa_lista_debito()
    End Sub

    Protected Sub bt_gerar_lista_financa_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_gerar_lista_financa.Click
        pesquisa_lista_financa()
    End Sub

    Protected Sub bt_gerar_relatorio_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_gerar_relatorio.Click

        If gd_lista_debito.Visible = True Then
            Gerar_Relatorio_Lista_Debito()
        ElseIf gd_clientes_agrupado.Visible = True Then
            Gerar_Relatorio_Lista_Debito_Agrupado()
        ElseIf gd_lista_financa.Visible = True Then
            Gerar_Relatorio_Lista_Financa()
        Else

        End If

    End Sub

End Class

