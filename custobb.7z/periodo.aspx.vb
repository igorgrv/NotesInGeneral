﻿Imports MySql.Data.MySqlClient
Imports System.Data
Imports System.Drawing
Imports System.IO
Partial Class periodo
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Retorna_Cliente()
            Retorna_Grupo()
            ImageAviso.Visible = False
            gridClientes.Visible = False
            Pesquisa_Atualizacao()
        End If


    End Sub
    Private Sub Pesquisa_Atualizacao()
        Dim adoconn As New ADODB.Connection
        adoconn.Open(Application("custobb").ToString())

        Dim rs_controle As New ADODB.Recordset
        Dim sql As Object

        sql = "SELECT DATA_CRED FROM tb_rec_valores_agendados_yv_bkp order by DATA_CRED LIMIT 1"
        rs_controle.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        If Not rs_controle.EOF Then
            referencia.Text = rs_controle.Fields("DATA_CRED").Value
        Else
            Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
        End If
        rs_controle.Close()

        rs_controle = Nothing
        adoconn.Close()
        adoconn = Nothing

    End Sub
    Protected Sub bt_gerar_relatorio_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles bt_gerar_relatorio.Click

        If ck_agrupar.Checked And ck_agrupar_online.Checked = False Then
            Gerar_Relatorio_Cobranca_Agrupado()
        ElseIf ck_agrupar.Checked = False And ck_agrupar_online.Checked = False Then
            Gerar_Relatorio_Cobranca()
        ElseIf ck_agrupar.Checked And ck_agrupar_online.Checked Then
            Gerar_Relatorio_Cobranca_Agrupado_Online()
        ElseIf ck_agrupar.Checked = False And ck_agrupar_online.Checked Then
            Gerar_Relatorio_Cobranca_online()

        End If

    End Sub


    Private Sub ck_agrupar_checked(ByVal sender As Object, ByVal e As EventArgs) Handles ck_agrupar.CheckedChanged
        If ck_agrupar.Checked Then
            txt_pesquisa_gtv.Visible = False
        Else
            txt_pesquisa_gtv.Visible = True
        End If
    End Sub


    Private Sub Retorna_Grupo()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset

        adoconn.Open(Util.conexao)
        txt_grupo.Items.Add("")

        Dim var_sql1 As Object
        var_sql1 = "SELECT tb_cliente.GRUPO FROM(tb_cliente) WHERE(tb_cliente.GRUPO Is Not NULL Or tb_cliente.GRUPO <> 0) GROUP BY tb_cliente.GRUPO ORDER BY tb_cliente.GRUPO"

        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        Do While Not rs_dados.EOF
            txt_grupo.Items.Add(rs_dados("GRUPO").Value)
            rs_dados.MoveNext()
        Loop
        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub

    Private Sub Retorna_Cliente()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset

        adoconn.Open(Util.conexao)
        txt_cliente.Items.Add("")

        Dim var_sql1 As Object
        var_sql1 = "SELECT tb_rec_valores_agendados_yv_bkp.NOM_CLIENTE FROM tb_rec_valores_agendados_yv_bkp GROUP BY tb_rec_valores_agendados_yv_bkp.NOM_CLIENTE ORDER BY tb_rec_valores_agendados_yv_bkp.NOM_CLIENTE"

        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        Do While Not rs_dados.EOF
            txt_cliente.Items.Add(rs_dados("nom_cliente").Value)
            rs_dados.MoveNext()
        Loop
        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' Verifies that the control is rendered
    End Sub
    <System.Web.Services.WebMethodAttribute()> <System.Web.Script.Services.ScriptMethodAttribute()> Public Shared Function GetDynamicContent(ByVal contextKey As System.String) As System.String
        '
    End Function

    Protected Sub Gerar_Relatorio_Cobranca()

        pesquisa_clientes()

        'gd_clientes.Columns(0).Visible = True
        'gd_clientes.Columns(1).Visible = False

        Response.Clear()
        Response.ContentEncoding = System.Text.Encoding.UTF8

        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=Relatorio de Clientes.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"

        Using sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)
            Response.Write("<meta http-equiv='content-type' content='application/xhtml+xml; charset=UTF-8' />")

            'ESCONDE COLUNA COM LINK

            gd_clientes.HeaderRow.BackColor = Drawing.Color.White
            For Each cell As TableCell In gd_clientes.HeaderRow.Cells
                cell.BackColor = Drawing.Color.Red
                cell.ForeColor = Drawing.Color.White
            Next
            For Each row As GridViewRow In gd_clientes.Rows
                row.BackColor = Drawing.Color.White
                For Each cell As TableCell In row.Cells
                    If row.RowIndex Mod 2 = 0 Then
                        cell.BackColor = Drawing.Color.White
                    Else
                        cell.BackColor = Drawing.Color.LightGray
                    End If
                    cell.CssClass = "textmode"
                Next
            Next

            gd_clientes.RenderControl(hw)
            'style to format numbers to string
            Dim style As String = "<style> .textmode { } </style>"
            Response.Write(style)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End Using

    End Sub


    Protected Sub Gerar_Relatorio_Cobranca_Agrupado()

        pesquisa_clientes()

        'gd_clientes.Columns(0).Visible = True
        'gd_clientes.Columns(1).Visible = False

        Response.Clear()
        Response.ContentEncoding = System.Text.Encoding.UTF8

        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=Relatorio de Clientes.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"

        Using sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)
            Response.Write("<meta http-equiv='content-type' content='application/xhtml+xml; charset=UTF-8' />")

            'ESCONDE COLUNA COM LINK

            gd_clientes_agrupado.HeaderRow.BackColor = Drawing.Color.White
            For Each cell As TableCell In gd_clientes_agrupado.HeaderRow.Cells
                cell.BackColor = Drawing.Color.Red
                cell.ForeColor = Drawing.Color.White
            Next
            For Each row As GridViewRow In gd_clientes_agrupado.Rows
                row.BackColor = Drawing.Color.White
                For Each cell As TableCell In row.Cells
                    If row.RowIndex Mod 2 = 0 Then
                        cell.BackColor = Drawing.Color.White
                    Else
                        cell.BackColor = Drawing.Color.LightGray
                    End If
                    cell.CssClass = "textmode"
                Next
            Next

            gd_clientes_agrupado.RenderControl(hw)
            'style to format numbers to string
            Dim style As String = "<style> .textmode { } </style>"
            Response.Write(style)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End Using

    End Sub
    Protected Sub Gerar_Relatorio_Cobranca_Agrupado_Online()

        pesquisa_clientes()

        'gd_clientes.Columns(0).Visible = True
        'gd_clientes.Columns(1).Visible = False

        Response.Clear()
        Response.ContentEncoding = System.Text.Encoding.UTF8

        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=Relatorio de Clientes.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"

        Using sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)
            Response.Write("<meta http-equiv='content-type' content='application/xhtml+xml; charset=UTF-8' />")

            'ESCONDE COLUNA COM LINK

            gd_clientes_agrupado_online.HeaderRow.BackColor = Drawing.Color.White
            For Each cell As TableCell In gd_clientes_agrupado_online.HeaderRow.Cells
                cell.BackColor = Drawing.Color.Red
                cell.ForeColor = Drawing.Color.White
            Next
            For Each row As GridViewRow In gd_clientes_agrupado_online.Rows
                row.BackColor = Drawing.Color.White
                For Each cell As TableCell In row.Cells
                    If row.RowIndex Mod 2 = 0 Then
                        cell.BackColor = Drawing.Color.White
                    Else
                        cell.BackColor = Drawing.Color.LightGray
                    End If
                    cell.CssClass = "textmode"
                Next
            Next

            gd_clientes_agrupado_online.RenderControl(hw)
            'style to format numbers to string
            Dim style As String = "<style> .textmode { } </style>"
            Response.Write(style)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End Using

    End Sub

    Protected Sub Gerar_Relatorio_Cobranca_online()

        pesquisa_clientes()

        'gd_clientes.Columns(0).Visible = True
        'gd_clientes.Columns(1).Visible = False

        Response.Clear()
        Response.ContentEncoding = System.Text.Encoding.UTF8

        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=Relatorio de Clientes.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"

        Using sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)
            Response.Write("<meta http-equiv='content-type' content='application/xhtml+xml; charset=UTF-8' />")

            'ESCONDE COLUNA COM LINK

            gd_clientes_online.HeaderRow.BackColor = Drawing.Color.White
            For Each cell As TableCell In gd_clientes_online.HeaderRow.Cells
                cell.BackColor = Drawing.Color.Red
                cell.ForeColor = Drawing.Color.White
            Next
            For Each row As GridViewRow In gd_clientes_online.Rows
                row.BackColor = Drawing.Color.White
                For Each cell As TableCell In row.Cells
                    If row.RowIndex Mod 2 = 0 Then
                        cell.BackColor = Drawing.Color.White
                    Else
                        cell.BackColor = Drawing.Color.LightGray
                    End If
                    cell.CssClass = "textmode"
                Next
            Next

            gd_clientes_online.RenderControl(hw)
            'style to format numbers to string
            Dim style As String = "<style> .textmode { } </style>"
            Response.Write(style)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End Using

    End Sub


    Protected Sub bt_pesquisa_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_pesquisa.Click
        pesquisa_clientes()
        pesquisa_clientes()
    End Sub

    Protected Sub OnPageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gd_clientes.PageIndex = e.NewPageIndex
        pesquisa_clientes()
    End Sub

    Protected Sub OnPageIndexChangingAgrupado(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gd_clientes_agrupado.PageIndex = e.NewPageIndex
        pesquisa_clientes()
    End Sub

    Protected Sub OnPageIndexChangingOnlineAgrupado(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gd_clientes_agrupado_online.PageIndex = e.NewPageIndex
        pesquisa_clientes()
    End Sub

    Protected Sub OnPageIndexChangingOnline(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gd_clientes_online.PageIndex = e.NewPageIndex
        pesquisa_clientes()
    End Sub


    Protected Sub Pinta_Grid()

        Dim qtd_linhas As Double = 0
        Dim valorRecolhido As Double = 0

        If ck_agrupar.Checked = False And ck_agrupar_online.Checked Then
            For Each row As GridViewRow In gd_clientes_online.Rows

                If row.RowType = DataControlRowType.DataRow Then

                    If IsNumeric(row.Cells(15).Text) Then
                        valorRecolhido = valorRecolhido + CDbl(row.Cells(15).Text)
                    End If

                    qtd_linhas = qtd_linhas + 1

                End If
            Next
        End If

        If ck_agrupar.Checked And ck_agrupar_online.Checked Then
            For Each row As GridViewRow In gd_clientes_agrupado_online.Rows

                If row.RowType = DataControlRowType.DataRow Then

                    If IsNumeric(row.Cells(14).Text) Then
                        valorRecolhido = valorRecolhido + CDbl(row.Cells(14).Text)
                    End If

                    qtd_linhas = qtd_linhas + 1

                End If
            Next
        End If

        If ck_agrupar.Checked And ck_agrupar_online.Checked = False Then

            For Each row As GridViewRow In gd_clientes_agrupado.Rows

                If row.RowType = DataControlRowType.DataRow Then

                    If IsNumeric(row.Cells(14).Text) Then
                        valorRecolhido = valorRecolhido + CDbl(row.Cells(14).Text)
                    End If

                    qtd_linhas = qtd_linhas + 1

                End If
            Next
        End If

        If ck_agrupar.Checked = False And ck_agrupar_online.Checked = False Then
            For Each row As GridViewRow In gd_clientes.Rows

                If row.RowType = DataControlRowType.DataRow Then

                    If IsNumeric(row.Cells(15).Text) Then
                        valorRecolhido = valorRecolhido + CDbl(row.Cells(15).Text)
                    End If

                    qtd_linhas = qtd_linhas + 1

                End If
            Next
        End If

        'lbl_numero_pontos.Text = qtd_linhas
        lbl_total_recolhido.Text = FormatCurrency(valorRecolhido)
        lbl_total_registros.Text = (qtd_linhas)

    End Sub





    Protected Sub pesquisa_clientes(Optional ByVal numeroLinhas As Integer = 0)

        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String
        Dim cirterioTarifa As String = ""


        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        conexaoMySQL.Open()

        'gd_clientes.Columns(0).Visible = True

        strSQL = "SET GLOBAL innodb_lock_wait_timeout = 10000"
        daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
        dsMySQL = New DataSet
        daMySQL.SelectCommand.CommandTimeout = 99999
        daMySQL.Fill(dsMySQL, "Produtos")

        'If txt_pesquisa_gtv.Text <> "" Then

        strSQL = ""
        strSQL = " SELECT DISTINCT "
        strSQL = strSQL & " tb_rec_valores_agendados_yv_bkp.AGENCIA_CLI, tb_segmento.SEGMENTO, tb_rec_valores_agendados_yv_bkp.CONTA_CLI, tb_cliente.GRUPO, tb_rec_valores_agendados_yv_bkp.CNPJ_CLI, tb_rec_valores_agendados_yv_bkp.NOM_CLIENTE, tb_rec_valores_agendados_yv_bkp.COD_LOCAL, "
        strSQL = strSQL & " tb_rec_valores_agendados_yv_bkp.NOM_LOCAL, tb_ponto_new.PRODUTO, tb_rec_valores_agendados_yv_bkp.NUM_CONV,  tb_ponto_new.TIPO_CONTRATO, tb_transportadora.CNPJ_TRANSPORTADORA, tb_transportadora.FILIAL_TRANSPORTADORA, "
        strSQL = strSQL & " tb_rec_valores_agendados_yv_bkp.COD_GTV, tb_rec_valores_agendados_yv_bkp.VAL_REC_APUR / 100 as VAL_REC_APUR, tb_rec_valores_agendados_yv_bkp.DATA_REC, tb_rec_valores_agendados_yv_bkp.DATA_CRED"
        strSQL = strSQL & " FROM  tb_rec_valores_agendados_yv_bkp"
        strSQL = strSQL & " INNER JOIN tb_cliente ON tb_cliente.CNPJ_CLI = tb_rec_valores_agendados_yv_bkp.CNPJ_CLI"
        strSQL = strSQL & " INNER JOIN tb_segmento ON tb_cliente.SEGMENTO = tb_segmento.SEGMENTO_ID"
        strSQL = strSQL & " INNER JOIN tb_ponto_new ON tb_ponto_new.CODIGO_PONTO = tb_rec_valores_agendados_yv_bkp.CODIGO_PONTO"
        strSQL = strSQL & " INNER JOIN tb_transportadora ON tb_ponto_new.PENUMPER_TRA = tb_transportadora.COD_PESSOA_TRANSP"
        strSQL = strSQL & " WHERE tb_rec_valores_agendados_yv_bkp.NOM_CLIENTE LIKE '%" & Trim(txt_cliente.Text) & "%' AND tb_cliente.GRUPO LIKE '%" & Trim(txt_grupo.Text) & "%' "

        'ElseIf txt_pesquisa_gtv.Text = "" Then
        '    strSQL = ""
        '    strSQL = " SELECT DISTINCT "
        '    strSQL = strSQL & " tb_rec_valores_agendados_yv_bkp.CNPJ_CLI, tb_rec_valores_agendados_yv_bkp.NOM_CLIENTE, tb_rec_valores_agendados_yv_bkp.COD_LOCAL, "
        '    strSQL = strSQL & " tb_rec_valores_agendados_yv_bkp.NOM_LOCAL, tb_rec_valores_agendados_yv_bkp.NUM_CONV, tb_rec_valores_agendados_yv_bkp.CNPJ_TRA, tb_rec_valores_agendados_yv_bkp.NOM_TRANSPORTADORA, "
        '    strSQL = strSQL & " tb_rec_valores_agendados_yv_bkp.VAL_REC_APUR / 100 as VAL_REC_APUR"
        '    strSQL = strSQL & " FROM  tb_rec_valores_agendados_yv_bkp"
        '    strSQL = strSQL & " WHERE tb_rec_valores_agendados_yv_bkp.NOM_CLIENTE LIKE '%" & Trim(txt_cliente.Text) & "%'"

        'End If
        If ck_agrupar_online.Checked Then
            strSQL = ""
            strSQL = "SELECT DISTINCT tb_rec_valores_online.CODIGO_CLIENTE, tb_segmento.SEGMENTO, tb_rec_valores_online.CRAL_CONV, tb_rec_valores_online.CONTA_CLI, tb_ponto_new.TIPO_CONTRATO, tb_rec_valores_online.NOM_CLI, tb_rec_valores_online.COD_LOCAL, tb_rec_valores_online.NOM_LOCAL, "
            strSQL = strSQL & " tb_rec_valores_online.NUM_CONV, tb_rec_valores_online.COD_GTV, tb_transportadora.CNPJ_TRANSPORTADORA, tb_transportadora.FILIAL_TRANSPORTADORA,tb_rec_valores_online.VAL_REC_APUR, tb_rec_valores_online.DATA_REC, tb_rec_valores_online.DATA_CRED, tb_rec_valores_online.HORA_CRED, tb_rec_valores_online.MINUTO_CRED, "
            strSQL = strSQL & " tb_cliente.GRUPO, tb_ponto_new.PRODUTO, tb_rec_valores_online.VAL_REC_APUR "
            strSQL = strSQL & " FROM  tb_rec_valores_online"
            strSQL = strSQL & " INNER JOIN tb_cliente ON tb_cliente.CNPJ_CLI = tb_rec_valores_online.CODIGO_CLIENTE"
            strSQL = strSQL & " INNER JOIN tb_segmento ON tb_cliente.SEGMENTO = tb_segmento.SEGMENTO_ID"
            strSQL = strSQL & " INNER JOIN tb_ponto_new ON tb_ponto_new.CODIGO_PONTO = tb_rec_valores_online.CODIGO_PONTO INNER JOIN tb_transportadora ON tb_ponto_new.PENUMPER_TRA = tb_transportadora.COD_PESSOA_TRANSP"
            strSQL = strSQL & " WHERE tb_rec_valores_online.NOM_CLI LIKE '%" & Trim(txt_cliente.Text) & "%' AND tb_cliente.GRUPO LIKE '%" & Trim(txt_grupo.Text) & "%'"
        End If

        If ck_agrupar_online.Checked And ck_agrupar.Checked Then
            strSQL = ""
            strSQL = "SELECT tb_rec_valores_online.CODIGO_CLIENTE, tb_segmento.SEGMENTO, tb_rec_valores_online.CRAL_CONV, tb_rec_valores_online.CONTA_CLI, tb_ponto_new.TIPO_CONTRATO, tb_rec_valores_online.NOM_CLI, tb_transportadora.CNPJ_TRANSPORTADORA, tb_transportadora.FILIAL_TRANSPORTADORA, tb_rec_valores_online.COD_LOCAL, tb_rec_valores_online.NOM_LOCAL, tb_rec_valores_online.NUM_CONV, "
            strSQL = strSQL & " tb_cliente.GRUPO, tb_ponto_new.PRODUTO, (Sum(tb_rec_valores_online.VAL_REC_APUR)) AS VAL_REC_APUR,  max(DATA_REC) AS ULT_CRED"
            strSQL = strSQL & " FROM  tb_rec_valores_online"
            strSQL = strSQL & " INNER JOIN tb_cliente ON tb_cliente.CNPJ_CLI = tb_rec_valores_online.CODIGO_CLIENTE"
            strSQL = strSQL & " INNER JOIN tb_segmento ON tb_cliente.SEGMENTO = tb_segmento.SEGMENTO_ID"
            strSQL = strSQL & " INNER JOIN tb_ponto_new ON tb_ponto_new.CODIGO_PONTO = tb_rec_valores_online.CODIGO_PONTO INNER JOIN tb_transportadora ON tb_ponto_new.PENUMPER_TRA = tb_transportadora.COD_PESSOA_TRANSP"
            strSQL = strSQL & " WHERE tb_rec_valores_online.NOM_CLI LIKE '%" & Trim(txt_cliente.Text) & "%' AND tb_cliente.GRUPO LIKE '%" & Trim(txt_grupo.Text) & "%'"
        End If

        If ck_agrupar.Checked And ck_agrupar_online.Checked = False Then
            strSQL = ""
            strSQL = " SELECT  "
            strSQL = strSQL & " tb_rec_valores_agendados_yv_bkp.AGENCIA_CLI, tb_segmento.SEGMENTO, tb_rec_valores_agendados_yv_bkp.CONTA_CLI, tb_rec_valores_agendados_yv_bkp.CNPJ_CLI, tb_cliente.GRUPO, tb_rec_valores_agendados_yv_bkp.NOM_CLIENTE, "
            strSQL = strSQL & " tb_rec_valores_agendados_yv_bkp.COD_LOCAL, tb_rec_valores_agendados_yv_bkp.NOM_LOCAL, tb_ponto_new.PRODUTO, tb_ponto_new.TIPO_CONTRATO, tb_rec_valores_agendados_yv_bkp.NUM_CONV, tb_transportadora.CNPJ_TRANSPORTADORA, "
            strSQL = strSQL & " tb_transportadora.FILIAL_TRANSPORTADORA, (Sum(tb_rec_valores_agendados_yv_bkp.VAL_OCT_APUR))/100 AS VAL_REC_APUR,  max(DATA_REC) AS ULT_CRED"
            strSQL = strSQL & " FROM tb_rec_valores_agendados_yv_bkp"
            strSQL = strSQL & " INNER JOIN tb_cliente ON tb_cliente.CNPJ_CLI = tb_rec_valores_agendados_yv_bkp.CNPJ_CLI"
            strSQL = strSQL & " INNER JOIN tb_segmento ON tb_cliente.SEGMENTO = tb_segmento.SEGMENTO_ID"
            strSQL = strSQL & " INNER JOIN tb_ponto_new ON tb_ponto_new.CODIGO_PONTO = tb_rec_valores_agendados_yv_bkp.CODIGO_PONTO "
            strSQL = strSQL & " INNER JOIN tb_transportadora ON tb_ponto_new.PENUMPER_TRA = tb_transportadora.COD_PESSOA_TRANSP "
            strSQL = strSQL & " WHERE tb_rec_valores_agendados_yv_bkp.NOM_CLIENTE LIKE '%" & Trim(txt_cliente.Text) & "%' AND tb_cliente.GRUPO LIKE '%" & Trim(txt_grupo.Text) & "%' "
        End If

        If txt_produto.Text = "RECICLADORA" Then
            If (ck_agrupar_online.Checked) Then
                strSQL = strSQL & " and tb_ponto_new.PRODUTO= 'RECICLADORA'"
            Else
                strSQL = strSQL & " and tb_rec_valores_agendados_yv_bkp.CNPJ_TRA = 51427102000129"
            End If
        End If

        If ck_segmento.Text = "SCIB" Then
            strSQL = strSQL & " and tb_segmento.SEGMENTO = 'SCIB'"
        ElseIf ck_segmento.Text = "CORPORATE" Then
            strSQL = strSQL & " and tb_segmento.SEGMENTO = 'CORPORATE'"
        ElseIf ck_segmento.Text = "VAREJO" Then
            strSQL = strSQL & " and tb_segmento.SEGMENTO = 'VAREJO'"
        End If

        If txt_produto.Text = "COFRE" Then
            strSQL = strSQL & " and (tb_ponto_new.PRODUTO= 'COFRE' OR tb_ponto_new.PRODUTO= 'COFRE_D1') "
        End If

        If txt_produto.Text = "RV" Then
            strSQL = strSQL & " and tb_ponto_new.PRODUTO= 'RV'"
        End If

        If txt_contratacao.Text = "BANCO" Then
            strSQL = strSQL & " AND tb_ponto_new.TIPO_CONTRATO = 'BANCO' "
        End If
        If txt_contratacao.Text = "DIRETO" Then
            strSQL = strSQL & " AND tb_ponto_new.TIPO_CONTRATO = 'DIRETO' "
        End If

        If txt_pesquisa_cnpj.Text <> "" Then
            If (ck_agrupar_online.Checked) Then
                strSQL = strSQL & " and tb_rec_valores_online.CODIGO_CLIENTE = " & Trim(txt_pesquisa_cnpj.Text)
            Else
                strSQL = strSQL & " and tb_rec_valores_agendados_yv_bkp.CNPJ_CLI = " & Trim(txt_pesquisa_cnpj.Text)
            End If
        End If

        If txt_pesquisa_gtv.Text <> "" Then
            If (ck_agrupar_online.Checked) Then
                strSQL = strSQL & " AND tb_rec_valores_online.COD_GTV Like '%" & Trim(txt_pesquisa_gtv.Text) & "%'"
            Else
                strSQL = strSQL & " AND tb_rec_valores_agendados_yv_bkp.COD_GTV Like '%" & Trim(txt_pesquisa_gtv.Text) & "%'"
            End If
        End If

        If txt_codigo_ponto.Text <> "" Then
            If (ck_agrupar_online.Checked) Then
                strSQL = strSQL & " AND tb_rec_valores_online.COD_LOCAL Like '%" & Trim(txt_codigo_ponto.Text) & "%'"
            Else
                strSQL = strSQL & " AND tb_rec_valores_agendados_yv_bkp.COD_LOCAL Like '%" & Trim(txt_codigo_ponto.Text) & "%'"
            End If
        End If

        If txt_inicio.Text <> "" And txt_fim.Text = "" Then
            If (ck_agrupar_online.Checked) Then
                strSQL = strSQL & " and tb_rec_valores_online.DATA_REC >= DATE_FORMAT(STR_TO_DATE('" & Trim(txt_inicio.Text) & "', '%d/%m/%Y'), '%Y-%m-%d')"
            Else
                strSQL = strSQL & " And tb_rec_valores_agendados_yv_bkp.DATA_REC >= DATE_FORMAT(STR_TO_DATE('" & Trim(txt_inicio.Text) & "', '%d/%m/%Y'), '%Y-%m-%d')"
            End If

        ElseIf txt_inicio.Text <> "" And txt_fim.Text <> "" Then

            If (ck_agrupar_online.Checked) Then
                strSQL = strSQL & " and tb_rec_valores_online.DATA_REC between DATE_FORMAT(STR_TO_DATE('" & Trim(txt_inicio.Text) & "', '%d/%m/%Y'), '%Y-%m-%d') And DATE_FORMAT(STR_TO_DATE('" & Trim(txt_fim.Text) & "', '%d/%m/%Y'), '%Y-%m-%d')"
            Else
                strSQL = strSQL & " and tb_rec_valores_agendados_yv_bkp.DATA_REC between DATE_FORMAT(STR_TO_DATE('" & Trim(txt_inicio.Text) & "', '%d/%m/%Y'), '%Y-%m-%d') And DATE_FORMAT(STR_TO_DATE('" & Trim(txt_fim.Text) & "', '%d/%m/%Y'), '%Y-%m-%d')"
            End If

        ElseIf txt_fim.Text <> "" And txt_inicio.Text = "" Then

            If (ck_agrupar_online.Checked) Then
                strSQL = strSQL & " and tb_rec_valores_online.DATA_REC <= DATE_FORMAT(STR_TO_DATE('" & Trim(txt_fim.Text) & "', '%d/%m/%Y'), '%Y-%m-%d')"
            Else
                strSQL = strSQL & " and tb_rec_valores_agendados_yv_bkp.DATA_REC <= DATE_FORMAT(STR_TO_DATE('" & Trim(txt_fim.Text) & "', '%d/%m/%Y'), '%Y-%m-%d')"
            End If

        End If

        If txt_inicio_cred.Text <> "" And txt_fim_cred.Text = "" Then
            If (ck_agrupar_online.Checked) Then
                strSQL = strSQL & " and tb_rec_valores_online.DATA_CRED >= DATE_FORMAT(STR_TO_DATE('" & Trim(txt_inicio_cred.Text) & "', '%d/%m/%Y'), '%Y-%m-%d')"
            Else
                strSQL = strSQL & " And tb_rec_valores_agendados_yv_bkp.DATA_CRED >= DATE_FORMAT(STR_TO_DATE('" & Trim(txt_inicio_cred.Text) & "', '%d/%m/%Y'), '%Y-%m-%d')"
            End If

        ElseIf txt_inicio_cred.Text <> "" And txt_fim_cred.Text <> "" Then

            If (ck_agrupar_online.Checked) Then
                strSQL = strSQL & " and tb_rec_valores_online.DATA_CRED between DATE_FORMAT(STR_TO_DATE('" & Trim(txt_inicio_cred.Text) & "', '%d/%m/%Y'), '%Y-%m-%d') And DATE_FORMAT(STR_TO_DATE('" & Trim(txt_fim_cred.Text) & "', '%d/%m/%Y'), '%Y-%m-%d')"
            Else
                strSQL = strSQL & " and tb_rec_valores_agendados_yv_bkp.DATA_CRED between DATE_FORMAT(STR_TO_DATE('" & Trim(txt_inicio_cred.Text) & "', '%d/%m/%Y'), '%Y-%m-%d') And DATE_FORMAT(STR_TO_DATE('" & Trim(txt_fim_cred.Text) & "', '%d/%m/%Y'), '%Y-%m-%d')"
            End If

        ElseIf txt_fim_cred.Text <> "" And txt_inicio_cred.Text = "" Then

            If (ck_agrupar_online.Checked) Then
                strSQL = strSQL & " and tb_rec_valores_online.DATA_CRED <= DATE_FORMAT(STR_TO_DATE('" & Trim(txt_fim_cred.Text) & "', '%d/%m/%Y'), '%Y-%m-%d')"
            Else
                strSQL = strSQL & " and tb_rec_valores_agendados_yv_bkp.DATA_CRED <= DATE_FORMAT(STR_TO_DATE('" & Trim(txt_fim_cred.Text) & "', '%d/%m/%Y'), '%Y-%m-%d')"
            End If

        End If

        If (ck_agrupar.Checked And ck_agrupar_online.Checked = False) Then
            strSQL = strSQL & " GROUP BY tb_rec_valores_agendados_yv_bkp.COD_LOCAL, "
            strSQL = strSQL & " tb_rec_valores_agendados_yv_bkp.NOM_LOCAL, tb_rec_valores_agendados_yv_bkp.NUM_CONV"

            strSQL = strSQL & " ORDER BY tb_rec_valores_agendados_yv_bkp.CNPJ_CLI"

            daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
            dsMySQL = New DataSet
            daMySQL.SelectCommand.CommandTimeout = 99999
            daMySQL.Fill(dsMySQL, "Produtos")
            gd_clientes_agrupado.DataSource = dsMySQL
            gd_clientes_agrupado.DataBind()

            conexaoMySQL.Close()
            conexaoMySQL = Nothing

            gd_clientes_agrupado.Columns(0).Visible = False

            gd_clientes.Columns(0).Visible = False
            gd_clientes.Columns(1).Visible = False
            gd_clientes.Columns(2).Visible = False
            gd_clientes.Columns(3).Visible = False
            gd_clientes.Columns(4).Visible = False
            gd_clientes.Columns(5).Visible = False
            gd_clientes.Columns(6).Visible = False
            gd_clientes.Columns(7).Visible = False
            gd_clientes.Columns(8).Visible = False
            gd_clientes.Columns(9).Visible = False
            gd_clientes.Columns(10).Visible = False
            gd_clientes.Columns(11).Visible = False
            gd_clientes.Columns(12).Visible = False
            gd_clientes.Columns(13).Visible = False
            gd_clientes.Columns(14).Visible = False
            gd_clientes.Columns(15).Visible = False
            gd_clientes.Columns(16).Visible = False
            gd_clientes.Columns(17).Visible = False

            gd_clientes_online.Columns(0).Visible = False
            gd_clientes_online.Columns(1).Visible = False
            gd_clientes_online.Columns(2).Visible = False
            gd_clientes_online.Columns(3).Visible = False
            gd_clientes_online.Columns(4).Visible = False
            gd_clientes_online.Columns(5).Visible = False
            gd_clientes_online.Columns(6).Visible = False
            gd_clientes_online.Columns(7).Visible = False
            gd_clientes_online.Columns(8).Visible = False
            gd_clientes_online.Columns(9).Visible = False
            gd_clientes_online.Columns(10).Visible = False
            gd_clientes_online.Columns(11).Visible = False
            gd_clientes_online.Columns(12).Visible = False
            gd_clientes_online.Columns(13).Visible = False
            gd_clientes_online.Columns(14).Visible = False
            gd_clientes_online.Columns(14).Visible = False
            gd_clientes_online.Columns(15).Visible = False
            gd_clientes_online.Columns(16).Visible = False
            gd_clientes_online.Columns(17).Visible = False
            gd_clientes_online.Columns(18).Visible = False
            gd_clientes_online.Columns(19).Visible = False

            gd_clientes_agrupado_online.Columns(0).Visible = False
            gd_clientes_agrupado_online.Columns(1).Visible = False
            gd_clientes_agrupado_online.Columns(2).Visible = False
            gd_clientes_agrupado_online.Columns(3).Visible = False
            gd_clientes_agrupado_online.Columns(4).Visible = False
            gd_clientes_agrupado_online.Columns(5).Visible = False
            gd_clientes_agrupado_online.Columns(6).Visible = False
            gd_clientes_agrupado_online.Columns(7).Visible = False
            gd_clientes_agrupado_online.Columns(8).Visible = False
            gd_clientes_agrupado_online.Columns(9).Visible = False
            gd_clientes_agrupado_online.Columns(10).Visible = False
            gd_clientes_agrupado_online.Columns(11).Visible = False
            gd_clientes_agrupado_online.Columns(12).Visible = False
            gd_clientes_agrupado_online.Columns(13).Visible = False
            gd_clientes_agrupado_online.Columns(14).Visible = False
            gd_clientes_agrupado_online.Columns(15).Visible = False

            gd_clientes_agrupado.Columns(0).Visible = False
            gd_clientes_agrupado.Columns(1).Visible = True
            gd_clientes_agrupado.Columns(2).Visible = True
            gd_clientes_agrupado.Columns(3).Visible = True
            gd_clientes_agrupado.Columns(4).Visible = True
            gd_clientes_agrupado.Columns(5).Visible = True
            gd_clientes_agrupado.Columns(6).Visible = True
            gd_clientes_agrupado.Columns(7).Visible = True
            gd_clientes_agrupado.Columns(8).Visible = True
            gd_clientes_agrupado.Columns(9).Visible = True
            gd_clientes_agrupado.Columns(10).Visible = True
            gd_clientes_agrupado.Columns(11).Visible = True
            gd_clientes_agrupado.Columns(12).Visible = True
            gd_clientes_agrupado.Columns(13).Visible = True
            gd_clientes_agrupado.Columns(14).Visible = True
            gd_clientes_agrupado.Columns(15).Visible = True

            If gd_clientes_agrupado.Rows.Count = 0 Then
                Imageaviso1.Visible = True
                gridClientes.Visible = True
            Else
                Imageaviso1.Visible = False
                gridClientes.Visible = True
            End If



        ElseIf (ck_agrupar.Checked = False And ck_agrupar_online.Checked = False) Then

            strSQL = strSQL & " ORDER BY tb_rec_valores_agendados_yv_bkp.DATA_REC"

            daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
            dsMySQL = New DataSet
            daMySQL.SelectCommand.CommandTimeout = 99999
            daMySQL.Fill(dsMySQL, "Produtos")
            gd_clientes.DataSource = dsMySQL
            gd_clientes.DataBind()


            conexaoMySQL.Close()
            conexaoMySQL = Nothing

            gd_clientes_agrupado.Columns(0).Visible = False
            gd_clientes_agrupado.Columns(1).Visible = False
            gd_clientes_agrupado.Columns(2).Visible = False
            gd_clientes_agrupado.Columns(3).Visible = False
            gd_clientes_agrupado.Columns(4).Visible = False
            gd_clientes_agrupado.Columns(5).Visible = False
            gd_clientes_agrupado.Columns(6).Visible = False
            gd_clientes_agrupado.Columns(7).Visible = False
            gd_clientes_agrupado.Columns(8).Visible = False
            gd_clientes_agrupado.Columns(9).Visible = False
            gd_clientes_agrupado.Columns(10).Visible = False
            gd_clientes_agrupado.Columns(11).Visible = False
            gd_clientes_agrupado.Columns(12).Visible = False
            gd_clientes_agrupado.Columns(13).Visible = False
            gd_clientes_agrupado.Columns(14).Visible = False
            gd_clientes_agrupado.Columns(15).Visible = False

            gd_clientes_online.Columns(0).Visible = False
            gd_clientes_online.Columns(1).Visible = False
            gd_clientes_online.Columns(2).Visible = False
            gd_clientes_online.Columns(3).Visible = False
            gd_clientes_online.Columns(4).Visible = False
            gd_clientes_online.Columns(5).Visible = False
            gd_clientes_online.Columns(6).Visible = False
            gd_clientes_online.Columns(7).Visible = False
            gd_clientes_online.Columns(8).Visible = False
            gd_clientes_online.Columns(9).Visible = False
            gd_clientes_online.Columns(10).Visible = False
            gd_clientes_online.Columns(11).Visible = False
            gd_clientes_online.Columns(12).Visible = False
            gd_clientes_online.Columns(13).Visible = False
            gd_clientes_online.Columns(14).Visible = False
            gd_clientes_online.Columns(15).Visible = False
            gd_clientes_online.Columns(16).Visible = False
            gd_clientes_online.Columns(17).Visible = False
            gd_clientes_online.Columns(18).Visible = False
            gd_clientes_online.Columns(19).Visible = False

            gd_clientes_agrupado_online.Columns(0).Visible = False
            gd_clientes_agrupado_online.Columns(1).Visible = False
            gd_clientes_agrupado_online.Columns(2).Visible = False
            gd_clientes_agrupado_online.Columns(3).Visible = False
            gd_clientes_agrupado_online.Columns(4).Visible = False
            gd_clientes_agrupado_online.Columns(5).Visible = False
            gd_clientes_agrupado_online.Columns(6).Visible = False
            gd_clientes_agrupado_online.Columns(7).Visible = False
            gd_clientes_agrupado_online.Columns(8).Visible = False
            gd_clientes_agrupado_online.Columns(9).Visible = False
            gd_clientes_agrupado_online.Columns(10).Visible = False
            gd_clientes_agrupado_online.Columns(11).Visible = False
            gd_clientes_agrupado_online.Columns(12).Visible = False
            gd_clientes_agrupado_online.Columns(13).Visible = False
            gd_clientes_agrupado_online.Columns(14).Visible = False
            gd_clientes_agrupado_online.Columns(15).Visible = False

            gd_clientes.Columns(0).Visible = False
            gd_clientes.Columns(1).Visible = True
            gd_clientes.Columns(2).Visible = True
            gd_clientes.Columns(3).Visible = True
            gd_clientes.Columns(4).Visible = True
            gd_clientes.Columns(5).Visible = True
            gd_clientes.Columns(6).Visible = True
            gd_clientes.Columns(7).Visible = True
            gd_clientes.Columns(8).Visible = True
            gd_clientes.Columns(9).Visible = True
            gd_clientes.Columns(10).Visible = True
            gd_clientes.Columns(11).Visible = True
            gd_clientes.Columns(12).Visible = True
            gd_clientes.Columns(13).Visible = True
            gd_clientes.Columns(14).Visible = True
            gd_clientes.Columns(15).Visible = True
            gd_clientes.Columns(16).Visible = True
            gd_clientes.Columns(17).Visible = True


            If gd_clientes.Rows.Count = 0 Then
                Imageaviso1.Visible = True
                gridClientes.Visible = True
            Else
                Imageaviso1.Visible = False
                gridClientes.Visible = True
            End If


        ElseIf (ck_agrupar.Checked = False And ck_agrupar_online.Checked) Then

            strSQL = strSQL & " ORDER BY tb_rec_valores_online.DATA_REC"

            daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
            dsMySQL = New DataSet
            daMySQL.SelectCommand.CommandTimeout = 99999
            daMySQL.Fill(dsMySQL, "Produtos")
            gd_clientes_online.DataSource = dsMySQL
            gd_clientes_online.DataBind()


            conexaoMySQL.Close()
            conexaoMySQL = Nothing

            gd_clientes_agrupado.Columns(0).Visible = False
            gd_clientes_agrupado.Columns(1).Visible = False
            gd_clientes_agrupado.Columns(2).Visible = False
            gd_clientes_agrupado.Columns(3).Visible = False
            gd_clientes_agrupado.Columns(4).Visible = False
            gd_clientes_agrupado.Columns(5).Visible = False
            gd_clientes_agrupado.Columns(6).Visible = False
            gd_clientes_agrupado.Columns(7).Visible = False
            gd_clientes_agrupado.Columns(8).Visible = False
            gd_clientes_agrupado.Columns(9).Visible = False
            gd_clientes_agrupado.Columns(10).Visible = False
            gd_clientes_agrupado.Columns(11).Visible = False
            gd_clientes_agrupado.Columns(12).Visible = False
            gd_clientes_agrupado.Columns(13).Visible = False
            gd_clientes_agrupado.Columns(14).Visible = False
            gd_clientes_agrupado.Columns(15).Visible = False

            gd_clientes.Columns(0).Visible = False
            gd_clientes.Columns(1).Visible = False
            gd_clientes.Columns(2).Visible = False
            gd_clientes.Columns(3).Visible = False
            gd_clientes.Columns(4).Visible = False
            gd_clientes.Columns(5).Visible = False
            gd_clientes.Columns(6).Visible = False
            gd_clientes.Columns(7).Visible = False
            gd_clientes.Columns(8).Visible = False
            gd_clientes.Columns(9).Visible = False
            gd_clientes.Columns(10).Visible = False
            gd_clientes.Columns(11).Visible = False
            gd_clientes.Columns(12).Visible = False
            gd_clientes.Columns(13).Visible = False
            gd_clientes.Columns(14).Visible = False
            gd_clientes.Columns(15).Visible = False
            gd_clientes.Columns(16).Visible = False
            gd_clientes.Columns(17).Visible = False

            gd_clientes_agrupado_online.Columns(0).Visible = False
            gd_clientes_agrupado_online.Columns(1).Visible = False
            gd_clientes_agrupado_online.Columns(2).Visible = False
            gd_clientes_agrupado_online.Columns(3).Visible = False
            gd_clientes_agrupado_online.Columns(4).Visible = False
            gd_clientes_agrupado_online.Columns(5).Visible = False
            gd_clientes_agrupado_online.Columns(6).Visible = False
            gd_clientes_agrupado_online.Columns(7).Visible = False
            gd_clientes_agrupado_online.Columns(8).Visible = False
            gd_clientes_agrupado_online.Columns(9).Visible = False
            gd_clientes_agrupado_online.Columns(10).Visible = False
            gd_clientes_agrupado_online.Columns(11).Visible = False
            gd_clientes_agrupado_online.Columns(12).Visible = False
            gd_clientes_agrupado_online.Columns(13).Visible = False
            gd_clientes_agrupado_online.Columns(14).Visible = False
            gd_clientes_agrupado_online.Columns(15).Visible = False

            gd_clientes_online.Columns(0).Visible = False
            gd_clientes_online.Columns(1).Visible = True
            gd_clientes_online.Columns(2).Visible = True
            gd_clientes_online.Columns(3).Visible = True
            gd_clientes_online.Columns(4).Visible = True
            gd_clientes_online.Columns(5).Visible = True
            gd_clientes_online.Columns(6).Visible = True
            gd_clientes_online.Columns(7).Visible = True
            gd_clientes_online.Columns(8).Visible = True
            gd_clientes_online.Columns(9).Visible = True
            gd_clientes_online.Columns(10).Visible = True
            gd_clientes_online.Columns(11).Visible = True
            gd_clientes_online.Columns(12).Visible = True
            gd_clientes_online.Columns(13).Visible = True
            gd_clientes_online.Columns(14).Visible = True
            gd_clientes_online.Columns(15).Visible = True
            gd_clientes_online.Columns(16).Visible = True
            gd_clientes_online.Columns(17).Visible = True
            gd_clientes_online.Columns(18).Visible = True
            gd_clientes_online.Columns(19).Visible = True

            If gd_clientes_online.Rows.Count = 0 Then
                Imageaviso1.Visible = True
                gridClientes.Visible = True
            Else
                Imageaviso1.Visible = False
                gridClientes.Visible = True
            End If

        ElseIf (ck_agrupar.Checked And ck_agrupar_online.Checked) Then

            strSQL = strSQL & " GROUP BY tb_rec_valores_online.CODIGO_CLIENTE, tb_cliente.GRUPO, tb_ponto_new.PRODUTO, "
            strSQL = strSQL & " tb_rec_valores_online.NOM_CLI, tb_rec_valores_online.COD_LOCAL, "
            strSQL = strSQL & " tb_rec_valores_online.NOM_LOCAL, tb_rec_valores_online.NUM_CONV"

            strSQL = strSQL & " ORDER BY tb_rec_valores_online.CODIGO_CLIENTE"

            daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
            dsMySQL = New DataSet
            daMySQL.SelectCommand.CommandTimeout = 99999
            daMySQL.Fill(dsMySQL, "Produtos")
            gd_clientes_agrupado_online.DataSource = dsMySQL
            gd_clientes_agrupado_online.DataBind()


            conexaoMySQL.Close()
            conexaoMySQL = Nothing

            gd_clientes_agrupado.Columns(0).Visible = False
            gd_clientes_agrupado.Columns(1).Visible = False
            gd_clientes_agrupado.Columns(2).Visible = False
            gd_clientes_agrupado.Columns(3).Visible = False
            gd_clientes_agrupado.Columns(4).Visible = False
            gd_clientes_agrupado.Columns(5).Visible = False
            gd_clientes_agrupado.Columns(6).Visible = False
            gd_clientes_agrupado.Columns(7).Visible = False
            gd_clientes_agrupado.Columns(8).Visible = False
            gd_clientes_agrupado.Columns(9).Visible = False
            gd_clientes_agrupado.Columns(10).Visible = False
            gd_clientes_agrupado.Columns(11).Visible = False
            gd_clientes_agrupado.Columns(12).Visible = False
            gd_clientes_agrupado.Columns(13).Visible = False
            gd_clientes_agrupado.Columns(14).Visible = False
            gd_clientes_agrupado.Columns(15).Visible = False

            gd_clientes.Columns(0).Visible = False
            gd_clientes.Columns(1).Visible = False
            gd_clientes.Columns(2).Visible = False
            gd_clientes.Columns(3).Visible = False
            gd_clientes.Columns(4).Visible = False
            gd_clientes.Columns(5).Visible = False
            gd_clientes.Columns(6).Visible = False
            gd_clientes.Columns(7).Visible = False
            gd_clientes.Columns(8).Visible = False
            gd_clientes.Columns(9).Visible = False
            gd_clientes.Columns(10).Visible = False
            gd_clientes.Columns(11).Visible = False
            gd_clientes.Columns(12).Visible = False
            gd_clientes.Columns(13).Visible = False
            gd_clientes.Columns(14).Visible = False
            gd_clientes.Columns(15).Visible = False
            gd_clientes.Columns(16).Visible = False
            gd_clientes.Columns(17).Visible = False

            gd_clientes_online.Columns(0).Visible = False
            gd_clientes_online.Columns(1).Visible = False
            gd_clientes_online.Columns(2).Visible = False
            gd_clientes_online.Columns(3).Visible = False
            gd_clientes_online.Columns(4).Visible = False
            gd_clientes_online.Columns(5).Visible = False
            gd_clientes_online.Columns(6).Visible = False
            gd_clientes_online.Columns(7).Visible = False
            gd_clientes_online.Columns(8).Visible = False
            gd_clientes_online.Columns(9).Visible = False
            gd_clientes_online.Columns(10).Visible = False
            gd_clientes_online.Columns(11).Visible = False
            gd_clientes_online.Columns(12).Visible = False
            gd_clientes_online.Columns(13).Visible = False
            gd_clientes_online.Columns(14).Visible = False
            gd_clientes_online.Columns(15).Visible = False
            gd_clientes_online.Columns(16).Visible = False
            gd_clientes_online.Columns(17).Visible = False
            gd_clientes_online.Columns(18).Visible = False
            gd_clientes_online.Columns(19).Visible = False

            gd_clientes_agrupado_online.Columns(0).Visible = False
            gd_clientes_agrupado_online.Columns(1).Visible = True
            gd_clientes_agrupado_online.Columns(2).Visible = True
            gd_clientes_agrupado_online.Columns(3).Visible = True
            gd_clientes_agrupado_online.Columns(4).Visible = True
            gd_clientes_agrupado_online.Columns(5).Visible = True
            gd_clientes_agrupado_online.Columns(6).Visible = True
            gd_clientes_agrupado_online.Columns(7).Visible = True
            gd_clientes_agrupado_online.Columns(8).Visible = True
            gd_clientes_agrupado_online.Columns(9).Visible = True
            gd_clientes_agrupado_online.Columns(10).Visible = True
            gd_clientes_agrupado_online.Columns(11).Visible = True
            gd_clientes_agrupado_online.Columns(12).Visible = True
            gd_clientes_agrupado_online.Columns(13).Visible = True
            gd_clientes_agrupado_online.Columns(14).Visible = True
            gd_clientes_agrupado_online.Columns(15).Visible = True

            If gd_clientes_agrupado_online.Rows.Count = 0 Then
                Imageaviso1.Visible = True
                gridClientes.Visible = True
            Else
                Imageaviso1.Visible = False
                gridClientes.Visible = True
            End If
        End If

        Pinta_Grid()

    End Sub
End Class
