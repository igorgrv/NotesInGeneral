﻿
Partial Class SemAcessoForm
    Inherits System.Web.UI.Page

End Class
