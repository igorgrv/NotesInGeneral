﻿Imports MySql.Data.MySqlClient
Imports System.Data
Imports System.Drawing
Imports System.IO
Partial Class CadastraUser
    Inherits System.Web.UI.Page

    Private Function User_Cadastrado(ByVal matricula As String) As Boolean

        Dim sql As String = ""
        Dim rs As New ADODB.Recordset
        Dim adoconn As New ADODB.Connection

        User_Cadastrado = False

        adoconn.Open(Util.conexao)

        sql = "SELECT login FROM tb_usuario WHERE login like '" & Trim(matricula) & "'"

        rs.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        If Not rs.EOF Then

            User_Cadastrado = True

        End If

        rs.Close()
        rs = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If Session("perfil") <> "Admin" Then
                Response.Redirect("SemAcessoForm.aspx")
            End If
            pesquisa_clientes()
            Pesquisa_filiais()
            pesquisa_mes_referencia()
            pesquisa_resultado()
        End If

    End Sub
    Protected Sub Pesquisa_filiais()
        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String

        strSQL = "SELECT * FROM tb_transportadora ORDER BY ID DESC"

        daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
        dsMySQL = New DataSet
        daMySQL.Fill(dsMySQL, "Produtos")
        gd_filiais.DataSource = dsMySQL
        gd_filiais.DataBind()

        conexaoMySQL.Open()

        conexaoMySQL.Close()
        conexaoMySQL = Nothing

        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "collapseThree", "$('#collapseThree').collapse('show');", True)

    End Sub

    Protected Sub pesquisa_clientes()

        gd_clientes.Columns(4).Visible = True
        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String

        strSQL = "SELECT * FROM TB_USUARIO where id_usuario > 0 "

        If txt_matricula.Text <> "" Then
            strSQL = strSQL & " and login Like '" & Trim(txt_matricula.Text) & "'"
        End If

        If txt_nome_completo.Text <> "" Then
            strSQL = strSQL & " and nome Like '%" & Trim(txt_nome_completo.Text) & "%'"
        End If

        strSQL = strSQL & " ORDER BY id_usuario DESC"

        daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
        dsMySQL = New DataSet
        daMySQL.Fill(dsMySQL, "Produtos")
        gd_clientes.DataSource = dsMySQL
        gd_clientes.DataBind()

        conexaoMySQL.Open()

        conexaoMySQL.Close()
        conexaoMySQL = Nothing
        gd_clientes.Columns(4).Visible = False
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "collapseTwo", "$('#collapseTwo').collapse('show');", True)


    End Sub
    Protected Sub pesquisa_resultado()

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String

        strSQL = "SELECT * FROM tb_resultado_produto ORDER BY id DESC"

        daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
        dsMySQL = New DataSet
        daMySQL.Fill(dsMySQL, "Produtos")
        gd_resultado.DataSource = dsMySQL
        gd_resultado.DataBind()

        conexaoMySQL.Open()

        conexaoMySQL.Close()
        conexaoMySQL = Nothing
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "collapseSix", "$('#collapseSix').collapse('show');", True)


    End Sub

    Protected Sub OnPageIndexChanging3(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gd_filiais.PageIndex = e.NewPageIndex
        Pesquisa_filiais()
    End Sub
    Protected Sub OnPageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gd_clientes.PageIndex = e.NewPageIndex
        pesquisa_clientes()
    End Sub
    Protected Sub OnPageIndexChanging2(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gd_mes_referencia.PageIndex = e.NewPageIndex
        pesquisa_mes_referencia()
    End Sub

    Protected Sub pesquisa_mes_referencia()

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String

        strSQL = "SELECT * FROM tb_cobranca_bb_referencia ORDER BY referenciaid DESC "

        daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
        dsMySQL = New DataSet
        daMySQL.Fill(dsMySQL, "Produtos")
        gd_mes_referencia.DataSource = dsMySQL
        gd_mes_referencia.DataBind()

        conexaoMySQL.Open()

        conexaoMySQL.Close()
        conexaoMySQL = Nothing

        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "collapseFifth", "$('#collapseFifth').collapse('show');", True)

    End Sub

    Protected Sub btnIncluiUser_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnIncluiUser.Click

        Dim matricula As String = ""
        Dim nomeCompleto As String = ""

        txt_nome_completo.Text = UCase(txt_nome_completo.Text)

        matricula = Trim(txt_matricula.Text)
        nomeCompleto = Trim(txt_nome_completo.Text)

        lbl_aviso.BackColor = Drawing.Color.Red

        If matricula = "" Or nomeCompleto = "" Then
            lbl_aviso.Text = "Informe corretamente a MATRÍCULA e o NOME COMPLETO do usuário."
            lbl_aviso.BackColor = Drawing.Color.White
            Exit Sub
        End If

        If User_Cadastrado(matricula) Then
            lbl_aviso.Text = "Este usuário já está cadastrado no sistema."
            lbl_aviso.BackColor = Drawing.Color.White
            Exit Sub
        End If

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())

        conexaoMySQL.Open()
        Dim cmd As New MySqlCommand("INSERT INTO tb_usuario ( Nome, login, Perfil, nome_aprovador, login_aprovador ) values('" & nomeCompleto & "' , '" & matricula & "', 'Consulta', '" & nomeCompleto & "', '" & matricula & "' )", conexaoMySQL)
        Dim result As Integer = cmd.ExecuteNonQuery()

        conexaoMySQL.Close()
        conexaoMySQL = Nothing
        cmd = Nothing

        lbl_aviso.BackColor = Drawing.Color.Green
        lbl_aviso.Text = "Usuário Cadastrado!"

        txt_matricula.Text = ""
        txt_nome_completo.Text = ""
        Response.Redirect("cadastrauser.aspx")

    End Sub

    Protected Sub bt_pesquisa_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_pesquisa.Click
        'lbl_aviso.Text = ""
        'lbl_aviso.BackColor = Drawing.Color.White
        pesquisa_clientes()
    End Sub

    Protected Sub Abrir_cliente(ByVal sender As Object, ByVal e As EventArgs)

        Dim row As GridViewRow = CType(CType(sender, LinkButton).Parent.Parent, GridViewRow)

        lbl_id.Text = row.Cells(4).Text
        lbl_id.Visible = True
        lbl_nome_user.Text = row.Cells(1).Text
        lbl_matricula_user.Text = row.Cells(2).Text
        cmb_perfil_novo.SelectedValue = row.Cells(3).Text

        'mp10.Show()
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "ModalAlteraUsuario", "$('#ModalAlteraUsuario').modal();", True)
        ModalAlteraUsuario.Update()

    End Sub
    Protected Sub Abrir_periodo(ByVal sender As Object, ByVal e As EventArgs)

        Dim row As GridViewRow = CType(CType(sender, LinkButton).Parent.Parent, GridViewRow)

        cmb_vigente.SelectedValue = row.Cells(13).Text
        lbl_periodo.Text = row.Cells(2).Text
        lbl_periodo.Visible = True
        lbl_dataDebito.Text = row.Cells(3).Text
        lbl_dataInicioM0.Text = row.Cells(4).Text
        lbl_dataFimM0.Text = row.Cells(5).Text
        lbl_dataInicioM1.Text = row.Cells(6).Text
        lbl_dataFimM1.Text = row.Cells(7).Text
        lbl_dataInicioFinancas.Text = row.Cells(8).Text
        lbl_dataFimFinancas.Text = row.Cells(9).Text
        lbl_dataInicioAut.Text = row.Cells(10).Text
        lbl_dataFimAut.Text = row.Cells(11).Text

        'mp10.Show()
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "ModalAlteraData", "$('#ModalAlteraData').modal();", True)
        ModalAlteraUsuario.Update()

    End Sub

    Protected Sub btnSalvar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSalvar.Click

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        conexaoMySQL.Open()

        Dim sql As String = "UPDATE tb_usuario SET Perfil='" & cmb_perfil_novo.SelectedValue & "', NOME ='" & Trim(lbl_nome_user.Text) & "', LOGIN= '" & Trim(lbl_matricula_user.Text) & "' WHERE id_usuario =" & lbl_id.Text

        Dim cmd As New MySqlCommand(sql, conexaoMySQL)
        Dim result As Integer = cmd.ExecuteNonQuery()

        conexaoMySQL.Close()

        pesquisa_clientes()

        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "modalAlteraAtivo", "$('.modal-backdrop').remove();$('body').removeClass('.pace-done modal-open');$('body').removeAttr( 'style' ); ", True)
        'lbl_aviso.Text = "Lista Atualizada!"

    End Sub
    Protected Sub btn_salva_periodo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_salva_periodo.Click

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        conexaoMySQL.Open()
        Dim sql As String = ""

        sql = "UPDATE tb_cobranca_bb_referencia "
        sql = sql & "SET data_limite ='" & Util.Formata_Data_Entrada(lbl_dataDebito.Text) & "', "
        sql = sql & "vigente ='" & Trim(cmb_vigente.SelectedValue) & "', "
        sql = sql & "dt_inicio_credito_m0 ='" & Util.Formata_Data_Entrada(lbl_dataInicioM0.Text) & "', "
        sql = sql & "dt_fim_credito_m0 ='" & Util.Formata_Data_Entrada(lbl_dataFimM0.Text) & "', "
        sql = sql & "dt_inicio_credito_m1 ='" & Util.Formata_Data_Entrada(lbl_dataInicioM1.Text) & "', "
        sql = sql & "dt_fim_credito_m1 ='" & Util.Formata_Data_Entrada(lbl_dataFimM1.Text) & "', "
        sql = sql & "dt_inicio_credito_financa ='" & Util.Formata_Data_Entrada(lbl_dataInicioFinancas.Text) & "', "
        sql = sql & "dt_fim_credito_financa ='" & Util.Formata_Data_Entrada(lbl_dataFimFinancas.Text) & "', "
        sql = sql & "dt_inicio_tarifaAutomatica ='" & Util.Formata_Data_Entrada(lbl_dataInicioAut.Text) & "', "
        sql = sql & "dt_fim_tarifaAutomatica ='" & Util.Formata_Data_Entrada(lbl_dataFimAut.Text) & "' "
        sql = sql & "WHERE mesAno = '" & lbl_periodo.Text & "'"

        Dim cmd As New MySqlCommand(sql, conexaoMySQL)
        Dim result As Integer = cmd.ExecuteNonQuery()

        conexaoMySQL.Close()

        pesquisa_mes_referencia()


        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "ModalAlteraData", "$('.modal-backdrop').remove();$('body').removeClass('.pace-done modal-open');$('body').removeAttr( 'style' ); ", True)
        'lbl_aviso.Text = "Lista Atualizada!"

    End Sub
    Protected Sub btn_salva_resultado_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_salva_resultado.Click

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        conexaoMySQL.Open()

        Dim sql As String = ""
        Dim referenciaResultado As String = Trim(txtResultadoRef.Text)
        Dim resultadoRv As String = Replace(Replace((Trim(txtResultadoRv.Text)), ".", ""), ",", ".")
        Dim resultadoCofre As String = Replace(Replace((Trim(txtResultadoCofre.Text)), ".", ""), ",", ".")
        Dim resultadoAtmr As String = Replace(Replace((Trim(txtResultadoATMR.Text)), ".", ""), ",", ".")
        Dim tarifaRv As String = Replace(Replace((Trim(txt_tarifa_rv.Text)), ".", ""), ",", ".")
        Dim tarifaCofre As String = Replace(Replace((Trim(txt_tarifa_cofre.Text)), ".", ""), ",", ".")
        Dim tarifaAtmr As String = Replace(Replace((Trim(txt_tarifa_atmr.Text)), ".", ""), ",", ".")
        Dim despesaRv As String = Replace(Replace((Trim(txt_despesa_rv.Text)), ".", ""), ",", ".")
        Dim despesaCofre As String = Replace(Replace((Trim(txt_despesa_cofre.Text)), ".", ""), ",", ".")
        Dim despesaAtmr As String = Replace(Replace((Trim(txt_despesa_atmr.Text)), ".", ""), ",", ".")
        Dim VolumeRv As String = Replace(Replace((Trim(txt_volume_rv.Text)), ".", ""), ",", ".")
        Dim VolumeCofre As String = Replace(Replace((Trim(txt_volume_cofre.Text)), ".", ""), ",", ".")
        Dim VolumeAtmr As String = Replace(Replace((Trim(txt_volume_atmr.Text)), ".", ""), ",", ".")


        If (referenciaResultado <> "" And resultadoRv <> "" And resultadoCofre <> "" And resultadoAtmr <> "" And tarifaRv <> "" And tarifaCofre <> "" And tarifaAtmr <> "" And despesaRv <> "" And despesaCofre <> "" And despesaAtmr <> "" And VolumeRv <> "" And VolumeCofre <> "" And VolumeAtmr <> "") Then
            sql = "INSERT INTO tb_resultado_produto "
            sql = sql & "(anoMes, resultadoCarroForte, resultadoCofre, resultadoRecicladora, tarifaCarroForte, tarifaCofre, tarifaRecicladora, "
            sql = sql & "despesaCarroForte, despesaCofre, despesaRecicladora, volumeCarroForte, volumeCofre, volumeRecicladora) "
            sql = sql & "VALUES ( '" & referenciaResultado & "', " & resultadoRv & ", " & resultadoCofre & ", " & resultadoAtmr & ", " & tarifaRv & ", " & tarifaCofre & ", "
            sql = sql & tarifaAtmr & ", " & despesaRv & ", " & despesaCofre & ", " & despesaAtmr & ", " & VolumeRv & ", " & VolumeCofre & ", " & VolumeAtmr & ") "

            Dim cmd As New MySqlCommand(sql, conexaoMySQL)
            Dim result As Integer = cmd.ExecuteNonQuery()
        End If

        conexaoMySQL.Close()
        conexaoMySQL = Nothing

        pesquisa_resultado()

    End Sub

    Protected Sub bt_salva_etv_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_salva_etv.Click


        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        conexaoMySQL.Open()

        For Each row As GridViewRow In gd_filiais.Rows
            System.Threading.Thread.Sleep(700)
            If row.RowType = DataControlRowType.DataRow Then
                Dim CODIGO_BASE As TextBox = TryCast(row.Cells(1).FindControl("CODIGO_BASE"), TextBox)
                Dim FILIAL_TRANSPORTADORA As TextBox = TryCast(row.Cells(4).FindControl("FILIAL_TRANSPORTADORA"), TextBox)
                Dim UF As TextBox = TryCast(row.Cells(5).FindControl("UF"), TextBox)
                Dim PRACA As TextBox = TryCast(row.Cells(6).FindControl("PRACA"), TextBox)

                Dim cmd As New MySqlCommand("UPDATE tb_transportadora SET CODIGO_BASE = '" & CODIGO_BASE.Text & "', FILIAL_TRANSPORTADORA = '" & FILIAL_TRANSPORTADORA.Text & "', UF = '" & UF.Text & "', PRACA = '" & PRACA.Text & "' WHERE id = " & row.Cells(0).Text, conexaoMySQL)
                Dim result As Integer = cmd.ExecuteNonQuery()
            End If

        Next

        conexaoMySQL.Close()
        conexaoMySQL = Nothing

    End Sub
    Protected Sub bt_alterar_mes_vigente_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_alterar_mes_vigente.Click


        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        conexaoMySQL.Open()

        For Each row As GridViewRow In gd_mes_referencia.Rows
            System.Threading.Thread.Sleep(700)
            If row.RowType = DataControlRowType.DataRow Then
                Dim txt_mes As TextBox = TryCast(row.Cells(4).FindControl("txt_mes_vigente"), TextBox)
                'Dim txt_porc As TextBox = TryCast(row.Cells(3).FindControl("ALIQUOTA"), TextBox)
                'Dim percDespesa As Double = txt_porc.Text
                'percDespesa = percDespesa / 100

                Dim cmd As New MySqlCommand("UPDATE tb_cobranca_bb_referencia SET vigente = '" & txt_mes.Text & "'" & " WHERE referenciaid = " & row.Cells(0).Text, conexaoMySQL)
                Dim result As Integer = cmd.ExecuteNonQuery()
            End If

        Next

        conexaoMySQL.Close()
        conexaoMySQL = Nothing

        pesquisa_mes_referencia()

    End Sub
    Protected Sub bt_referencia_nova_incluir_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_referencia_nova_incluir.Click

        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        conexaoMySQL.Open()

        If txt_referencia_nova.Text <> "" And txt_referencia_mesAno.Text <> "" And txt_dt_debito.Text <> "" And txt_dt_inicio_credito_m0.Text <> "" And txt_dt_fim_credito_m0.Text <> "" And txt_dt_inicio_credito_m1.Text <> "" And txt_dt_fim_credito_m1.Text <> "" And txt_dt_inicio_financas.Text <> "" And txt_dt_fim_financas.Text <> "" And txt_dt_inicio_automatico.Text <> "" And txt_dt_fim_automatico.Text <> "" And txt_despesa.Text <> "" Then
            Dim aliquotaDespesa = txt_despesa.Text / 100
            strSQL = "INSERT INTO tb_cobranca_bb_referencia "
            strSQL = strSQL & " (mesAno, referencia, data_limite, vigente, dt_inicio_credito_m0, dt_fim_credito_m0, dt_inicio_credito_m1, dt_fim_credito_m1, "
            strSQL = strSQL & " dt_inicio_credito_financa, dt_fim_credito_financa, dt_inicio_tarifaAutomatica, dt_fim_tarifaAutomatica, aliquota_despesa) "
            strSQL = strSQL & " values('" & txt_referencia_mesAno.Text & "', " & txt_referencia_nova.Text & " , '" & Util.Formata_Data_Entrada(txt_dt_debito.Text) & "' ,  'N' , ' " & Util.Formata_Data_Entrada(txt_dt_inicio_credito_m0.Text) & "' , '" & Util.Formata_Data_Entrada(txt_dt_fim_credito_m0.Text) & "' , '" & Util.Formata_Data_Entrada(txt_dt_inicio_credito_m1.Text) & "' , '" & Util.Formata_Data_Entrada(txt_dt_fim_credito_m1.Text) & "' , '" & Util.Formata_Data_Entrada(txt_dt_inicio_financas.Text) & "' , '" & Util.Formata_Data_Entrada(txt_dt_fim_financas.Text) & "' , '" & Util.Formata_Data_Entrada(txt_dt_inicio_automatico.Text) & "', '" & Util.Formata_Data_Entrada(txt_dt_fim_automatico.Text) & "' , '" & Replace(aliquotaDespesa, ",", ".") & "')"

            daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
            dsMySQL = New DataSet
            daMySQL.Fill(dsMySQL, "Produtos")
        Else
            Exit Sub
        End If

        conexaoMySQL.Close()
        conexaoMySQL = Nothing

        pesquisa_mes_referencia()

    End Sub

End Class
