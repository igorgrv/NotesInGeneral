﻿Imports MySql.Data.MySqlClient
Imports System.Data
Imports System.Drawing
Imports System.IO
Partial Class _Default
    Inherits System.Web.UI.Page
    
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If Session("perfil") = "Admin" Then
                li_debito.Visible = True
                li_usuarios.Visible = True
            End If
            Pesquisa_widget()
        End If

    End Sub

    Public Sub Pesquisa_widget()
        Dim adoconn As New ADODB.Connection
        adoconn.Open(Application("custobb").ToString())

        Dim rs_controle As New ADODB.Recordset
        Dim sql As Object

        sql = "SELECT format((sum(resultadoCarroForte + resultadoCofre + resultadoRecicladora)),2,'de_DE') as resultadoTotal, "
        sql = sql & " format(sum(resultadoCarroForte),2,'de_DE') as resultadoCarroForte, "
        sql = sql & " format(sum(resultadoCofre),2,'de_DE') as resultadoCofre, "
        sql = sql & " format(sum(resultadoRecicladora),2,'de_DE') as resultadoRecicladora, "
        sql = sql & " format((sum(volumeCarroForte + volumeCofre + volumeRecicladora)),2,'de_DE') as volumeTotal, "
        sql = sql & " format(sum(volumeCarroForte),2,'de_DE') as volumeCarroForte, "
        sql = sql & " format(sum(volumeCofre),2,'de_DE') as volumeCofre, "
        sql = sql & " format(sum(volumeRecicladora),2,'de_DE') as volumeRecicladora "
        sql = sql & " FROM tb_resultado_produto"
        rs_controle.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        If Not rs_controle.EOF Then
            resultadoTotal.Text = rs_controle.Fields("resultadoTotal").Value
            resultadoCarroForte.Text = rs_controle.Fields("resultadoCarroForte").Value
            resultadoCofre.Text = rs_controle.Fields("resultadoCofre").Value
            resultadoRecicladora.Text = rs_controle.Fields("resultadoRecicladora").Value
            volumeTotal.Text = rs_controle.Fields("volumeTotal").Value
            volumeCarroForte.Text = rs_controle.Fields("volumeCarroForte").Value
            volumeCofre.Text = rs_controle.Fields("volumeCofre").Value
            volumeRecicladora.Text = rs_controle.Fields("volumeRecicladora").Value
        Else
            Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
        End If

        rs_controle.Close()

        'PEGANDO REFERENCIA
        sql = "SELECT anoMes FROM tb_resultado_produto ORDER BY id DESC LIMIT 1 "
        rs_controle.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        If Not rs_controle.EOF Then
            referencia.Text = rs_controle.Fields("anoMes").Value
        Else
            Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
        End If
        rs_controle.Close()

        'PEGANDO PONTOS ATIVOS
        sql = "SELECT count(*) as pontosAtivo "
        sql = sql & "FROM tb_ponto_new WHERE PONTO_ATIVO = 'S'"
        rs_controle.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        If Not rs_controle.EOF Then
            lblPontoAtivo.Text = rs_controle.Fields("pontosAtivo").Value
        Else
            Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
        End If
        rs_controle.Close()

        'PONTO ATIVO COFRE
        sql = "SELECT count(*) as pontosAtivoCofre "
        sql = sql & "FROM tb_ponto_new WHERE PONTO_ATIVO = 'S' AND PRODUTO = 'COFRE'"
        rs_controle.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        If Not rs_controle.EOF Then
            lblPontoAtivoCofre.Text = rs_controle.Fields("pontosAtivoCofre").Value
        Else
            Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
        End If

        rs_controle.Close()

        'PONTO ATIVO RV
        sql = "SELECT count(*) as pontosAtivoRV "
        sql = sql & "FROM tb_ponto_new WHERE PONTO_ATIVO = 'S' AND PRODUTO = 'RV'"
        rs_controle.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        If Not rs_controle.EOF Then
            lblPontoAtivoRV.Text = rs_controle.Fields("pontosAtivoRV").Value
        Else
            Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
        End If

        rs_controle.Close()

        'PONTO ATIVO RECICLADORA
        sql = "SELECT count(*) as pontosAtivoRecicladora "
        sql = sql & "FROM tb_ponto_new WHERE PONTO_ATIVO = 'S' AND PRODUTO = 'RECICLADORA'"
        rs_controle.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        If Not rs_controle.EOF Then
            lblPontoAtivoRecicladora.Text = rs_controle.Fields("pontosAtivoRecicladora").Value
        Else
            Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
        End If

        rs_controle.Close()


        rs_controle = Nothing
        adoconn.Close()
        adoconn = Nothing

    End Sub



End Class
