﻿Imports MySql.Data.MySqlClient
Imports System.Data
Imports System.Drawing
Imports System.IO

Partial Class Default2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Dim adoconn As New ADODB.Connection
            Dim rs_dados As New ADODB.Recordset
            Dim strSQL As String = ""
            ImageAviso.Visible = False

            gridClientes.Visible = False

            adoconn.Open(Util.conexao)

            If Request("cod") <> "" Then

                strSQL = " SELECT * FROM tb_cliente"
                strSQL = strSQL & " WHERE"
                strSQL = strSQL & " CNPJ_CLI = " & Request("cod")

                rs_dados.Open(strSQL, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

                If Not rs_dados.EOF Then
                    lbl_cliente.Text = rs_dados.Fields("NOM_CLI").Value
                    lbl_cnpj_cli.Text = rs_dados.Fields("CNPJ_CLI").Value
                    Retorna_Conta_Corrente(Trim(rs_dados.Fields("CNPJ_CLI").Value))
                    cmb_tipo_cobranca.Text = rs_dados.Fields("PERIODO_COBRANCA").Value
                    cmb_tipo_tarifa.Text = rs_dados.Fields("TIPO_CADASTRO_TARIFA").Value

                    If (cmb_tipo_tarifa.Text = "PERCENTUAL POR PONTO") Then
                        lbl_Tarifa_Definida_Cnpj.Text = "VARIAVEL"
                    End If

                    cmb_tarifa_automatica.Text = rs_dados.Fields("COBRANCA_AUTOM").Value
                    If (rs_dados.Fields("COBRANCA_AUTOM").Value = "S") Then
                        cmb_tarifa_automatica.Text = "SIM"
                    Else
                        cmb_tarifa_automatica.Text = "NÃO"
                    End If

                    If cmb_tipo_tarifa.Text <> "PERCENTUAL POR PONTO" Then
                        Retorna_Valor_Aliquota_CNPJ(Request("cod"))
                    End If

                    carrega_combo_mes_hist()
                    Busca_Periodo_Cobranca()

                    If Session("perfil") = "Admin" Then
                        cmb_tipo_cobranca.Enabled = True
                        cmb_tipo_tarifa.Enabled = True
                        bt_pesquisar_ponto_tarifa.Visible = True
                        cmb_tarifa_automatica.Enabled = True
                    End If
                End If
            Else
            End If
            pesquisa_clientes()
            Pesquisa_Atualizacao()
        End If

    End Sub
    Private Sub Pesquisa_Atualizacao()
        Dim adoconn As New ADODB.Connection
        adoconn.Open(Application("custobb").ToString())

        Dim rs_controle As New ADODB.Recordset
        Dim sql As Object

        If cmb_tarifa_automatica.SelectedValue = "SIM" Then
            sql = "SELECT MES_REFERENCIA FROM tb_cobranca_bb_bkp INNER JOIN tb_cliente ON tb_cliente.CNPJ_CLI = tb_cobranca_bb_bkp.CNPJ "
            sql = sql & "WHERE tb_cliente.COBRANCA_AUTOM = 'S' ORDER BY COBRANCAID  LIMIT 1"
            rs_controle.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

            If rs_controle.EOF Then
                rs_controle.Close()
                sql = "SELECT MES_REFERENCIA FROM tb_cobranca_bb_historico INNER JOIN tb_cliente ON tb_cliente.CNPJ_CLI = tb_cobranca_bb_historico.CNPJ "
                sql = sql & "WHERE tb_cliente.COBRANCA_AUTOM = 'S' ORDER BY COBRANCAID  LIMIT 1"
                rs_controle.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

                referencia.Text = rs_controle.Fields("MES_REFERENCIA").Value
            Else
                referencia.Text = rs_controle.Fields("MES_REFERENCIA").Value
            End If
            rs_controle.Close()
        Else
            sql = "SELECT MES_REFERENCIA FROM tb_cobranca_bb_bkp INNER JOIN tb_cliente ON tb_cliente.CNPJ_CLI = tb_cobranca_bb_bkp.CNPJ "
            sql = sql & "WHERE tb_cliente.COBRANCA_AUTOM = 'N' ORDER BY COBRANCAID  LIMIT 1"
            rs_controle.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

            If rs_controle.EOF Then
                rs_controle.Close()
                sql = "SELECT MES_REFERENCIA FROM tb_cobranca_bb_historico INNER JOIN tb_cliente ON tb_cliente.CNPJ_CLI = tb_cobranca_bb_historico.CNPJ "
                sql = sql & "WHERE tb_cliente.COBRANCA_AUTOM = 'N' ORDER BY COBRANCAID  LIMIT 1"
                rs_controle.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

                referencia.Text = rs_controle.Fields("MES_REFERENCIA").Value
            Else
                referencia.Text = rs_controle.Fields("MES_REFERENCIA").Value
            End If

            rs_controle.Close()
        End If


        rs_controle = Nothing
        adoconn.Close()
        adoconn = Nothing

    End Sub
    Protected Sub bt_pesquisar_aliquota_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_pesquisar_aliquota.Click
        Response.Redirect("Fidelizacao.aspx?cod=" & lbl_cnpj_cli.Text)
    End Sub

    Sub Retorna_Conta_Corrente(ByVal cnpj As String)

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset
        Dim sql As String = ""

        adoconn.Open(Util.conexao)

        sql = "SELECT AG_CLI, CC_CLI "
        sql = sql & " FROM tb_cliente"
        sql = sql & " WHERE CNPJ_CLI = " & cnpj

        rs_dados.Open(sql, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)
        If Not rs_dados.EOF Then
            lbl_agencia_cli.Text = rs_dados.Fields("AG_CLI").Value
            lbl_conta_cli.Text = rs_dados.Fields("CC_CLI").Value
        End If
        rs_dados.Close()
        rs_dados = Nothing
        adoconn.Close()
        adoconn = Nothing

    End Sub

    Protected Sub Retorna_Valor_Aliquota_CNPJ(ByVal cnpj As String)

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset
        adoconn.Open(Util.conexao)

        Dim var_sql1 As Object
        var_sql1 = "SELECT CONCAT(TARIFA_FIXA,'%') as TARIFA_FIXA FROM tb_cliente WHERE CNPJ_CLI = " & cnpj

        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        If Not rs_dados.EOF Then

            If cmb_tipo_tarifa.Text = "PERCENTUAL POR CNPJ" Then
                lbl_Tarifa_Definida_Cnpj.Text = rs_dados("TARIFA_FIXA").Value
            ElseIf cmb_tipo_tarifa.Text = "PERCENTUAL POR PONTO" Then
                lbl_Tarifa_Definida_Cnpj.Text = "VARIAVEL"
            ElseIf cmb_tipo_tarifa.Text = "VALOR FIXO POR CNPJ" Then
                lbl_Tarifa_Definida_Cnpj.Text = "-"
            End If

        End If

        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub

    Protected Sub OnPageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gd_clientes.PageIndex = e.NewPageIndex
        pesquisa_clientes()
    End Sub

    '----------------------------------------------------------------------
    'ALTERA PERIODO M1 OU M0
    Protected Sub cmb_tipo_cobranca_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_tipo_cobranca.SelectedIndexChanged
        btnAlteraPeriodo.Visible = True
    End Sub

    Sub btnAlteraPeriodo_Click(ByVal sender As Object, ByVal e As EventArgs)
        lbl_Confirmar_Altera_Periodo.Text = "Confirma alteração da Modalidade de Cobrança?"
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "ModalAlteraPeriodo", "$('#ModalAlteraPeriodo').modal();", true)
        upModal.Update()
    End Sub

    Protected Sub bt_Aprovar_Altera_Periodo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_Aprovar_Altera_Periodo.Click
        Alterar_Tipo_Cobranca()
        Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
    End Sub

    '----------------------------------------------------------------------
    'ALTERA TIPO DE TARIFA / CNPJ OU POR PONTO
    Protected Sub cmb_tipo_tarifa_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_tipo_tarifa.SelectedIndexChanged
        btnAlteraTarifa.Visible = True
    End Sub

    Protected Sub btnAlteraTarifa_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        lbl_Altera_Tipo_Tarifa.Text = "Confirma alteração do Tipo de Tarifa?"
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "modalAlteraTarifa", "$('#modalAlteraTarifa').modal();", true)
        alteraTarifaModal.Update()
    End Sub

    Protected Sub bt_Confirma_Altera_Tipo_Tarifa_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_Confirma_Altera_Tipo_Tarifa.Click
        Alterar_Tipo_Tarifa()
        Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
    End Sub
        
    '----------------------------------------------------------------------
    'TARIFA AUTOMATICA
    Protected Sub cmb_tarifa_automatica_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_tarifa_automatica.SelectedIndexChanged
        btnAlteraAutomatico.Visible = True
    End Sub

    Protected Sub btnAlteraAutomatico_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        lbl_Altera_Tipo_Automatico.Text = "Confirma alteração da modalidade Automática?"
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "modalAlteraAutomatico", "$('#modalAlteraAutomatico').modal();", true)
        alteraAutomaticoModal.Update()
    End Sub

    Protected Sub bt_Confirma_Altera_Tipo_Automatico_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_Confirma_Altera_Tipo_Automatico.Click
        Alterar_Automatico()
        response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
    End Sub   

    '----------------------------------------------------------------------
    Protected Sub bt_pesquisar_ponto_tarifa_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_pesquisar_ponto_tarifa.Click

        If cmb_tipo_tarifa.Text = "PERCENTUAL POR PONTO" Then
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "modalAlteraPonto", "$('#modalAlteraPonto').modal();", true)
            alteraPontoModal.Update()
            pesquisa_tarifas_ponto()
        ElseIf cmb_tipo_tarifa.Text = "PERCENTUAL POR CNPJ" Then
            lbl_tarifa_por_cnpj.Text = "Informe o Percentual:"
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "modalTarifaCnpj", "$('#modalTarifaCnpj').modal();", true)
            tarifaCnpjModal.Update()
        ElseIf cmb_tipo_tarifa.Text = "VALOR FIXO POR CNPJ" Then
            lbl_tarifa_fixa.Text = "Informe o valor fixo:"
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "modalTarifaFixa", "$('#modalTarifaFixa').modal();", true)
            tarifaFixaModal.Update()
        End If

    End Sub
    
    Function Retorna_Tipo_Cadastro_Tarifa(ByVal cnpj As String) As String

        Dim adoconn1 As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset
        Dim sql As String = ""

        Retorna_Tipo_Cadastro_Tarifa = ""

        adoconn1.Open(Util.conexao)

        sql = "SELECT TIPO_CADASTRO_TARIFA FROM tb_cliente WHERE CNPJ_CLI = " & cnpj

        rs_dados.Open(sql, adoconn1, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        If Not rs_dados.EOF Then
            Retorna_Tipo_Cadastro_Tarifa = rs_dados.Fields("TIPO_CADASTRO_TARIFA").Value
        End If

        rs_dados.Close()
        rs_dados = Nothing

        adoconn1.Close()
        adoconn1 = Nothing

    End Function

    Protected Sub carrega_combo_mes_hist()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset
        adoconn.Open(Util.conexao)

        Dim var_sql2 As Object
        var_sql2 = "SELECT referencia, mesAno FROM tb_cobranca_bb_referencia ORDER BY referenciaid desc limit 1,100;"

        rs_dados.Open(var_sql2, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        Do While Not rs_dados.EOF
            cmb_referencia.Items.Add(rs_dados.Fields("mesAno").Value)
            rs_dados.MoveNext()
        Loop

        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub

    Sub Pinta_Grid()

        Dim qtd_linhas As Double = 0
        Dim valorTarifa As Double = 0
        Dim valorDeposito As Double = 0
        Dim valorDespesa As Double = 0
        Dim valorResultado As Double = 0

        For Each row As GridViewRow In gd_clientes.Rows

            If row.RowType = DataControlRowType.DataRow Then

                If IsNumeric(row.Cells(11).Text) Then
                    valorTarifa = valorTarifa + CDbl(row.Cells(11).Text)
                End If

                If IsNumeric(row.Cells(7).Text) Then
                    valorDeposito = valorDeposito + CDbl(row.Cells(7).Text)
                End If

                If IsNumeric(row.Cells(16).Text) Then
                    valorDespesa = valorDespesa + CDbl(row.Cells(16).Text)
                End If

                If IsNumeric(row.Cells(17).Text) Then
                    valorResultado = valorResultado + CDbl(row.Cells(17).Text)
                End If

                qtd_linhas = qtd_linhas + 1

                If row.Cells(11).Text = "R$ 0,00" Then
                    row.Cells(1).BackColor = Color.Yellow
                    row.Cells(2).BackColor = Color.Yellow
                    row.Cells(3).BackColor = Color.Yellow
                    row.Cells(4).BackColor = Color.Yellow
                    row.Cells(5).BackColor = Color.Yellow
                    row.Cells(6).BackColor = Color.Yellow
                    row.Cells(7).BackColor = Color.Yellow
                    row.Cells(8).BackColor = Color.Yellow
                    row.Cells(9).BackColor = Color.Yellow
                    row.Cells(10).BackColor = Color.Yellow
                    row.Cells(11).BackColor = Color.Yellow
                    row.Cells(12).BackColor = Color.Yellow
                    row.Cells(13).BackColor = Color.Yellow
                    row.Cells(14).BackColor = Color.Yellow
                    row.Cells(15).BackColor = Color.Yellow
                    row.Cells(16).BackColor = Color.Yellow
                    row.Cells(17).BackColor = Color.Yellow

                    If row.Cells(11).Text = "" Then
                        row.Cells(1).BackColor = Color.Yellow
                        row.Cells(2).BackColor = Color.Yellow
                        row.Cells(3).BackColor = Color.Yellow
                        row.Cells(4).BackColor = Color.Yellow
                        row.Cells(5).BackColor = Color.Yellow
                        row.Cells(6).BackColor = Color.Yellow
                        row.Cells(7).BackColor = Color.Yellow
                        row.Cells(8).BackColor = Color.Yellow
                        row.Cells(9).BackColor = Color.Yellow
                        row.Cells(10).BackColor = Color.Yellow
                        row.Cells(11).BackColor = Color.Yellow
                        row.Cells(12).BackColor = Color.Yellow
                        row.Cells(13).BackColor = Color.Yellow
                        row.Cells(14).BackColor = Color.Yellow
                        row.Cells(15).BackColor = Color.Yellow
                        row.Cells(16).BackColor = Color.Yellow
                        row.Cells(17).BackColor = Color.Yellow
                    End If
                End If
            End If
        Next

        lbl_numero_pontos.Text = qtd_linhas
        lbl_total_tarifa.Text = FormatCurrency(valorTarifa)
        lbl_total_recolhido.Text = FormatCurrency(valorDeposito)
        lbl_total_despesa.Text = FormatCurrency(valorDespesa)
        lbl_total_resultado.Text = FormatCurrency(valorResultado)

        If cmb_tipo_tarifa.Text = "VALOR FIXO POR CNPJ" Then
            lbl_total_tarifa.Text = FormatCurrency(lbl_Tarifa_Definida_Cnpj.Text)
        End If

    End Sub

    Protected Sub pesquisa_tarifas_ponto()

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String
        Dim mesReferencia As String = ""


        strSQL = "SELECT "
        strSQL = strSQL & " tb_tarifa_new.CODIGO_TARIFA, tb_ponto_new.CODIGO_PONTO, "
        strSQL = strSQL & " (tb_tarifa_new.TARIFA_VARIAVEL) AS TARIFA_BB, tb_ponto_new.COD_LOCAL, tb_ponto_new.NOM_LOCAL, "
        strSQL = strSQL & " tb_ponto_new.CODIGO_CONVENIO, tb_ponto_new.PRODUTO, tb_ponto_new.NOM_CID, tb_uf.UF, tb_ponto_new.TIPO_CONTRATO"
        strSQL = strSQL & " FROM (tb_cliente INNER JOIN (tb_tarifa_new INNER JOIN tb_ponto_new ON tb_tarifa_new.CODIGO_PONTO = tb_ponto_new.CODIGO_PONTO) ON tb_cliente.CNPJ_CLI = tb_ponto_new.CODIGO_CLIENTE) INNER JOIN tb_uf ON tb_ponto_new.COD_UF = tb_uf.COD_UF"
        strSQL = strSQL & " WHERE tb_cliente.CNPJ_CLI =" & Request("cod")

        strSQL = strSQL & " order by tb_ponto_new.CODIGO_CONVENIO" & " limit 100"

        daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
        dsMySQL = New DataSet
        daMySQL.Fill(dsMySQL, "Produtos")
        gd_clientes_pontos.DataSource = dsMySQL
        gd_clientes_pontos.DataBind()

        gd_clientes_pontos.Visible = True
        gd_clientes.Visible = False

        conexaoMySQL.Open()

        conexaoMySQL.Close()
        conexaoMySQL = Nothing

    End Sub


    Protected Sub pesquisa_clientes()

        Imageaviso.Visible = False
        gd_clientes_pontos.Visible = False
        gd_clientes.Visible = True

        gd_clientes.Columns(0).Visible = True
        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String = ""
        Dim mesReferencia As String = ""

        mesReferencia = Util.Retorna_Mes_vigente

        strSQL = strSQL & " SELECT tb_cobranca_bb_bkp.CUSTO_SPREAD AS TARIFA_BB,"
        strSQL = strSQL & " tb_cobranca_bb_bkp.COBRANCAID, "
        strSQL = strSQL & " tb_cliente.NOM_CLI, "
        strSQL = strSQL & " tb_ponto_new.COD_LOCAL, "
        strSQL = strSQL & " tb_ponto_new.NOM_LOCAL, "
        strSQL = strSQL & " tb_ponto_new.PRODUTO, "
        strSQL = strSQL & " tb_ponto_new.TIPO_CONTRATO, "
        strSQL = strSQL & " tb_ponto_new.CODIGO_CONVENIO, "
        strSQL = strSQL & " tb_cobranca_bb_bkp.VALOR_RECOLHIDO, "
        strSQL = strSQL & " tb_cobranca_bb_bkp.OBSERVACAO, "
        strSQL = strSQL & " tb_cobranca_bb_bkp.DATA_TARIFA, "
        strSQL = strSQL & " tb_cobranca_bb_bkp.CUSTO_SPREAD, "
        strSQL = strSQL & " tb_cobranca_bb_bkp.CUSTO_SPREAD_FIXO, "
        strSQL = strSQL & " tb_cobranca_bb_bkp.COBRANCA_PERCENTUAL, "
        strSQL = strSQL & " tb_cobranca_bb_bkp.VALOR_BB_FINAL, "
        strSQL = strSQL & " tb_cliente.CNPJ_CLI, "
        strSQL = strSQL & " tb_cobranca_bb_bkp.RECOLHIDO_DESPESA, tb_cobranca_bb_bkp.VALOR_DESPESA, tb_cobranca_bb_bkp.RESULTADO, "
        strSQL = strSQL & " tb_cobranca_bb_bkp.MES_REFERENCIA"
        strSQL = strSQL & " FROM tb_cliente INNER JOIN (tb_cobranca_bb_bkp INNER JOIN tb_ponto_new ON tb_cobranca_bb_bkp.CODIGO_PONTO = tb_ponto_new.CODIGO_PONTO) ON tb_cliente.CNPJ_CLI = tb_cobranca_bb_bkp.CNPJ"
        strSQL = strSQL & " WHERE tb_cobranca_bb_bkp.MES_REFERENCIA= '" & Request("referencia") & "' and tb_cliente.CNPJ_CLI='" & Request("cod") & "'"

        strSQL = strSQL & " order by tb_cobranca_bb_bkp.VALOR_BB_FINAL"

        daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
        dsMySQL = New DataSet
        daMySQL.Fill(dsMySQL, "Produtos")
        gd_clientes.DataSource = dsMySQL
        gd_clientes.DataBind()


        conexaoMySQL.Close()
        conexaoMySQL = Nothing

        If cmb_tarifa_automatica.Text = "NÃO" Then
            gd_clientes.Columns(12).Visible = False
        End If

        gd_clientes.Columns(0).Visible = False

        If gd_clientes.Rows.Count = 0 Then
            Imageaviso.Visible = True
            gridClientes.Visible = True
        Else
            gridClientes.Visible = True
        End If

        Pinta_Grid()
        Busca_Periodo_Cobranca()

    End Sub

    Protected Sub pesquisa_clientes_2()

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String = ""

        Imageaviso.Visible = False
        gd_clientes_pontos.Visible = False
        gd_clientes.Visible = True

        gd_clientes.Columns(0).Visible = True

        strSQL = strSQL & " SELECT CONCAT(tb_cobranca_bb_historico.CUSTO_SPREAD,'%')  AS TARIFA_BB,"
        strSQL = strSQL & " tb_cobranca_bb_historico.COBRANCAID, "
        strSQL = strSQL & " tb_cliente.NOM_CLI, "
        strSQL = strSQL & " tb_ponto_new.COD_LOCAL, "
        strSQL = strSQL & " tb_ponto_new.NOM_LOCAL, "
        strSQL = strSQL & " tb_ponto_new.PRODUTO, "
        strSQL = strSQL & " tb_ponto_new.TIPO_CONTRATO, "
        strSQL = strSQL & " tb_ponto_new.CODIGO_CONVENIO, "
        strSQL = strSQL & " tb_cobranca_bb_historico.VALOR_RECOLHIDO, "
        strSQL = strSQL & " tb_cobranca_bb_historico.CUSTO_SPREAD, "
        strSQL = strSQL & " tb_cobranca_bb_historico.OBSERVACAO, "
        strSQL = strSQL & " tb_cobranca_bb_historico.DATA_TARIFA, "
        strSQL = strSQL & " tb_cobranca_bb_historico.CUSTO_SPREAD, "
        strSQL = strSQL & " tb_cobranca_bb_historico.CUSTO_SPREAD_FIXO, "
        strSQL = strSQL & " tb_cobranca_bb_historico.COBRANCA_PERCENTUAL, "
        strSQL = strSQL & " tb_cobranca_bb_historico.VALOR_BB_FINAL, "
        strSQL = strSQL & " tb_cliente.CNPJ_CLI, "
        strSQL = strSQL & " tb_cobranca_bb_historico.RECOLHIDO_DESPESA, tb_cobranca_bb_historico.VALOR_DESPESA, tb_cobranca_bb_historico.RESULTADO, "
        strSQL = strSQL & " tb_cobranca_bb_historico.MES_REFERENCIA"
        strSQL = strSQL & " FROM tb_cliente INNER JOIN (tb_cobranca_bb_historico INNER JOIN tb_ponto_new ON tb_cobranca_bb_historico.CODIGO_PONTO = tb_ponto_new.CODIGO_PONTO) ON tb_cliente.CNPJ_CLI = tb_cobranca_bb_historico.CNPJ"
        strSQL = strSQL & " WHERE tb_cobranca_bb_historico.MES_REFERENCIA='" & cmb_referencia.Text & "' and tb_cliente.CNPJ_CLI='" & Request("cod") & "'"


        strSQL = strSQL & " order by tb_cobranca_bb_historico.VALOR_BB_FINAL"

        daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
        dsMySQL = New DataSet
        daMySQL.Fill(dsMySQL, "Produtos")
        gd_clientes.DataSource = dsMySQL
        gd_clientes.DataBind()

        conexaoMySQL.Open()
        conexaoMySQL.Close()
        conexaoMySQL = Nothing

        If cmb_tarifa_automatica.Text = "NÃO" Then
            gd_clientes.Columns(12).Visible = False
        End If

        gd_clientes.Columns(0).Visible = False
        If gd_clientes.Rows.Count = 0 Then
            Imageaviso.Visible = True
            gridClientes.Visible = True
        Else
            Imageaviso.Visible = False
            gridClientes.Visible = True
        End If
        Pinta_Grid()
        Busca_Periodo_Cobranca2()

        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "collapseTwo", "$('#collapseTwo').collapse('show');", True)
    End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As System.Web.UI.Control)
        'Do NOT call MyBase.VerifyRenderingInServerForm
    End Sub
    Protected Sub Gerar_Relatorio_Cobranca()

        Response.Clear()
        Response.ContentEncoding = System.Text.Encoding.UTF8

        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=Relatorio de Tarifa.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"

        Using sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)
            Response.Write("<meta http-equiv='content-type' content='application/xhtml+xml; charset=UTF-8' />")

            'To Export all pages
            gd_clientes.AllowPaging = False

            gd_clientes.HeaderRow.BackColor = Drawing.Color.White
            For Each cell As TableCell In gd_clientes.HeaderRow.Cells
                cell.BackColor = Drawing.Color.Red
                cell.ForeColor = Drawing.Color.White
            Next
            For Each row As GridViewRow In gd_clientes.Rows
                row.BackColor = Drawing.Color.White
                For Each cell As TableCell In row.Cells
                    If row.RowIndex Mod 2 = 0 Then
                        cell.BackColor = Drawing.Color.White
                    Else
                        cell.BackColor = Drawing.Color.LightGray
                    End If
                    cell.CssClass = "textmode"
                Next
            Next

            gd_clientes.RenderControl(hw)
            'style to format numbers to string
            Dim style As String = "<style> .textmode { } </style>"
            Response.Write(style)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End Using

    End Sub

    Protected Sub bt_gerar_relatorio_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_gerar_relatorio.Click
        Gerar_Relatorio_Cobranca()
    End Sub

    Protected Sub bt_pesquisar_ponto_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_pesquisar_ponto.Click
        pesquisa_clientes()
    End Sub

    Protected Sub bt_pesquisar_ponto_2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_pesquisar_ponto_2.Click
        pesquisa_clientes_2()
    End Sub

    Private Sub Busca_Periodo_Cobranca()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset
        Dim dtInicioCredito As String = ""
        Dim dtFimCredito As String = ""
        Dim dtdebito As String = ""

        adoconn.Open(Util.conexao)

        Dim var_sql1 As Object

        var_sql1 = "SELECT * "
        var_sql1 = var_sql1 & " FROM tb_cobranca_bb_referencia"
        var_sql1 = var_sql1 & " WHERE mesAno like '" & Request("referencia") & "'"

        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        If Not rs_dados.EOF Then
            If Trim(cmb_tipo_cobranca.Text) = "M0" And cmb_tarifa_automatica.Text = "SIM" Then
                dtInicioCredito = rs_dados("dt_inicio_tarifaAutomatica").Value
                dtFimCredito = rs_dados("dt_fim_tarifaAutomatica").Value
                dtdebito = "VIDE TABELA"
            ElseIf Trim(cmb_tipo_cobranca.Text) = "M0" And cmb_tarifa_automatica.Text = "NÃO" Then
                dtInicioCredito = rs_dados("dt_inicio_credito_m0").Value
                dtFimCredito = rs_dados("dt_fim_credito_m0").Value
                dtdebito = rs_dados("data_limite").Value
            ElseIf Trim(cmb_tipo_cobranca.Text) = "M1" And cmb_tarifa_automatica.Text = "SIM" Then
                dtInicioCredito = rs_dados("dt_inicio_tarifaAutomatica").Value
                dtFimCredito = rs_dados("dt_fim_tarifaAutomatica").Value
                dtdebito = "VIDE TABELA"
            Else
                dtInicioCredito = rs_dados("dt_inicio_credito_m1").Value
                dtFimCredito = rs_dados("dt_fim_credito_m1").Value
                dtdebito = rs_dados("data_limite").Value
            End If
            lbl_mes_atual.Text = rs_dados("mesAno").Value
        End If

        lbl_data_credito_ini.Text = dtInicioCredito
        lbl_data_credito_fim.Text = dtFimCredito
        lbl_data_debito.Text = dtdebito

        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub

    Private Sub Busca_Periodo_Cobranca2()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset
        Dim dtInicioCredito As String = ""
        Dim dtFimCredito As String = ""
        Dim dtdebito As String = ""
        Dim aliquota As String = ""

        adoconn.Open(Util.conexao)

        Dim var_sql2 As Object

        var_sql2 = "select * "
        var_sql2 = var_sql2 & " from tb_cobranca_bb_referencia"
        var_sql2 = var_sql2 & " WHERE mesAno like '" & cmb_referencia.Text & "'"

        rs_dados.Open(var_sql2, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)


        If Not rs_dados.EOF Then
            If Trim(cmb_tipo_cobranca.Text) = "M0" And cmb_tarifa_automatica.Text = "SIM" Then
                If Not IsDBNull(rs_dados("dt_inicio_tarifaAutomatica").Value) Then
                    dtInicioCredito = rs_dados("dt_inicio_tarifaAutomatica").Value
                    dtFimCredito = rs_dados("dt_fim_tarifaAutomatica").Value
                    dtdebito = "VIDE TABELA"
                Else
                    dtInicioCredito = rs_dados("dt_inicio_credito_m0").Value
                    dtFimCredito = rs_dados("dt_fim_credito_m0").Value
                    dtdebito = rs_dados("data_limite").Value
                End If
            ElseIf Trim(cmb_tipo_cobranca.Text) = "M0" And cmb_tarifa_automatica.Text = "NÃO" Then
                dtInicioCredito = rs_dados("dt_inicio_credito_m0").Value
                dtFimCredito = rs_dados("dt_fim_credito_m0").Value
                dtdebito = rs_dados("data_limite").Value
            ElseIf Trim(cmb_tipo_cobranca.Text) = "M1" And cmb_tarifa_automatica.Text = "SIM" Then
                If Not IsDBNull(rs_dados("dt_inicio_tarifaAutomatica").Value) Then
                    dtInicioCredito = rs_dados("dt_inicio_tarifaAutomatica").Value
                    dtFimCredito = rs_dados("dt_fim_tarifaAutomatica").Value
                    dtdebito = "VIDE TABELA"
                Else
                    dtInicioCredito = rs_dados("dt_inicio_credito_m0").Value
                    dtFimCredito = rs_dados("dt_fim_credito_m0").Value
                    dtdebito = rs_dados("data_limite").Value
                End If
            Else
                dtInicioCredito = rs_dados("dt_inicio_credito_m1").Value
                dtFimCredito = rs_dados("dt_fim_credito_m1").Value
                dtdebito = rs_dados("data_limite").Value
            End If
        End If

        lbl_data_credito_ini.Text = dtInicioCredito
        lbl_data_credito_fim.Text = dtFimCredito
        lbl_data_debito.Text = dtdebito

        lbl_Tarifa_Definida_Cnpj.Text = aliquota


        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub
 

    Protected Sub Alterar_Tipo_Cobranca()

        Dim adoconn As New ADODB.Connection
        Dim sql As String = ""

        sql = "UPDATE tb_cliente SET tb_cliente.PERIODO_COBRANCA = '" & cmb_tipo_cobranca.Text & "' WHERE tb_cliente.CNPJ_CLI = " & lbl_cnpj_cli.Text

        adoconn.Open(Util.conexao)
        adoconn.Execute(sql)
        adoconn.Close()
        adoconn = Nothing

        btnAlteraPeriodo.Visible = False

        Busca_Periodo_Cobranca()

    End Sub

    Protected Sub Alterar_Tipo_Tarifa()

        Dim adoconn As New ADODB.Connection
        Dim sql As String = ""
        sql = "UPDATE tb_cliente SET tb_cliente.TIPO_CADASTRO_TARIFA = '" & cmb_tipo_tarifa.Text & "' WHERE tb_cliente.CNPJ_CLI = " & lbl_cnpj_cli.Text
        adoconn.Open(Util.conexao)
        adoconn.Execute(sql)

        adoconn.Close()
        adoconn = Nothing

    End Sub

    Protected Sub Alterar_Automatico()

        Dim cmbTarifaAutomatica As String = ""

        If Trim(cmb_tarifa_automatica.Text) = "SIM" Then
            cmbTarifaAutomatica = "S"
        Else
            cmbTarifaAutomatica = "N"
        End if

        Dim adoconn As New ADODB.Connection
        Dim sql As String = ""
        sql = "UPDATE tb_cliente SET tb_cliente.COBRANCA_AUTOM = '" & cmbTarifaAutomatica & "' WHERE tb_cliente.CNPJ_CLI = " & lbl_cnpj_cli.Text
        adoconn.Open(Util.conexao)
        adoconn.Execute(sql)

        adoconn.Close()
        adoconn = Nothing

    End Sub


    Protected Sub bt_Salvar_valor_por_cnpj_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_Salvar_valor_por_cnpj.Click

        Dim adoconn As New ADODB.Connection
        Dim sql As String = ""
        Dim vlrTarifa As String = ""

        vlrTarifa = txt_valor_por_cnpj.Text

        vlrTarifa = Replace(vlrTarifa, ".", "")
        vlrTarifa = Replace(vlrTarifa, ",", ".")

        adoconn.Open(Util.conexao)

        sql = "UPDATE tb_cliente SET TARIFA_FIXA = " & vlrTarifa & " WHERE CNPJ_CLI = " & lbl_cnpj_cli.Text
        adoconn.Execute(sql)

        sql = "UPDATE tb_tarifa_new INNER JOIN tb_ponto_new ON tb_tarifa_new.CODIGO_PONTO = tb_ponto_new.CODIGO_PONTO SET tb_tarifa_new.TARIFA_VARIAVEL = 0, tb_tarifa_new.TARIFA_FIXA = " & vlrTarifa & " WHERE tb_ponto_new.CODIGO_CLIENTE = " & lbl_cnpj_cli.Text
        adoconn.Execute(sql)

        adoconn.Close()

        adoconn = Nothing

        Retorna_Valor_Aliquota_CNPJ(Request("cod"))
        
        Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
    End Sub

    Protected Sub bt_Salvar_tarifa_por_cnpj_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_Salvar_tarifa_por_cnpj.Click

        Dim adoconn As New ADODB.Connection
        Dim sql As String = ""
        Dim percTarifa As Double = 0
        Dim rs_dados As New ADODB.Recordset

        percTarifa = txt_tarifa_por_cnpj.Text

        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        conexaoMySQL.Open()

        adoconn.Open(Util.conexao)

        sql = "UPDATE tb_cliente SET TARIFA_FIXA = " & Replace(percTarifa, ",", ".") & " WHERE CNPJ_CLI = " & lbl_cnpj_cli.Text
        adoconn.Execute(sql)

        sql = "UPDATE tb_tarifa_new INNER JOIN tb_ponto_new ON tb_tarifa_new.CODIGO_PONTO = tb_ponto_new.CODIGO_PONTO SET tb_tarifa_new.TARIFA_VARIAVEL = " & Replace(percTarifa, ",", ".") & " WHERE tb_ponto_new.CODIGO_CLIENTE = " & lbl_cnpj_cli.Text
        adoconn.Execute(sql)

        adoconn.Close()
        adoconn = Nothing

        Retorna_Valor_Aliquota_CNPJ(Request("cod"))
        
        Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
    End Sub


    Protected Sub bt_Atualiza_Tarifa_PorPonto_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_Atualiza_Tarifa_PorPonto.Click

        Dim mesReferencia As String = ""
        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset


        Dim sql As String = ""
        Dim bloquearCliente As Boolean = False
        Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        conexaoMySQL.Open()

        For Each row As GridViewRow In gd_clientes_pontos.Rows
            If row.RowType = DataControlRowType.DataRow Then

                Dim txt_porc As TextBox = TryCast(row.Cells(6).FindControl("txt_tarifa_ponto"), TextBox)
                Dim percTarifa As Double = txt_porc.Text

                Dim codigoPonto As Long = 0
                Dim codigoTarifa As Long = 0
                codigoPonto = row.Cells(1).Text
                codigoTarifa = row.Cells(0).Text

                Dim txt_produt As TextBox = TryCast(row.Cells(3).FindControl("txt_produto_ponto"), TextBox)
                Dim txt_produto_text As String = txt_produt.Text

                Dim txt_contrato As TextBox = TryCast(row.Cells(4).FindControl("txt_contrato_ponto"), TextBox)
                Dim txt_contrato_ponto As String = txt_contrato.Text

                If txt_produto_text = "RV" Or txt_produto_text = "COFRE" Or txt_produto_text = "COFRE_D1" Or txt_produto_text = "RECICLADORA" Or txt_produto_text = "rv" Or txt_produto_text = "cofre_d1" Or txt_produto_text = "cofre" Or txt_produto_text = "recicladora" Or txt_contrato_ponto = "BANCO" Or txt_contrato_ponto = "banco" Or txt_contrato_ponto = "DIRETO" Or txt_contrato_ponto = "direto" Then

                    sql = ""
                    sql = sql & "UPDATE tb_tarifa_new INNER JOIN tb_ponto_new ON tb_tarifa_new.CODIGO_PONTO = tb_ponto_new.CODIGO_PONTO SET tb_ponto_new.PRODUTO = '" & txt_produto_text & "', tb_tarifa_new.TARIFA_VARIAVEL = " & Replace(percTarifa, ",", ".") & ", tb_ponto_new.TIPO_CONTRATO = '" & txt_contrato_ponto & "' WHERE tb_tarifa_new.CODIGO_TARIFA = " & codigoTarifa & " and  tb_ponto_new.CODIGO_PONTO = " & codigoPonto
                    Dim cmd As New MySqlCommand(sql, conexaoMySQL)
                    Dim result As Integer = cmd.ExecuteNonQuery()

                Else
                    Exit Sub
                End If
            End If

        Next

        conexaoMySQL.Close()
        conexaoMySQL = Nothing

        pesquisa_clientes()
        Pinta_Grid()

        Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)

    End Sub

    Protected Sub bt_Aplicar_Tar_Todos_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_Aplicar_Tar_Todos.Click

        For Each row As GridViewRow In gd_clientes_pontos.Rows
            If row.RowType = DataControlRowType.DataRow Then
                Dim txt_porc As TextBox = TryCast(row.Cells(6).FindControl("txt_tarifa_ponto"), TextBox)
                Dim percTarifa As Double = txt_Tar_Aplicar_Todos.Text

                'percTarifa = percTarifa / 100

                txt_porc.Text = percTarifa

            End If

        Next

        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "modalAlteraPonto", "$('#modalAlteraPonto').modal();", true)
        alteraPontoModal.Update()

    End Sub

End Class
