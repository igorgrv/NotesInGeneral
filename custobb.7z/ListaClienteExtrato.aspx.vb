﻿Imports MySql.Data.MySqlClient
Imports System.Data
Imports System.Drawing
Partial Class Default2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            'select_tarifado()

            'ImageAviso.Visible = False
            gridClientes.Visible = False

            Retorna_Especialistas()
            Retorna_Grupos()


            cmb_per_cobranca.Items.Add("M0")
            cmb_per_cobranca.Items.Add("M1")
            cmb_per_cobranca.Items.Add("TODOS")
            cmb_per_cobranca.Text = "TODOS"
        End If

    End Sub

    Private Sub Retorna_Especialistas()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset

        adoconn.Open(Util.conexao)

        cmb_especialista.Items.Add("TODOS")

        Dim var_sql1 As Object
        var_sql1 = "SELECT tb_cliente.ESPECIALISTA FROM tb_cliente GROUP BY tb_cliente.ESPECIALISTA HAVING (((tb_cliente.ESPECIALISTA) Is Not Null)) ORDER BY tb_cliente.ESPECIALISTA;"

        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        Do While Not rs_dados.EOF
            cmb_especialista.Items.Add(rs_dados("ESPECIALISTA").Value)
            rs_dados.MoveNext()
        Loop
        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub

    Private Sub Retorna_Grupos()

        Dim adoconn As New ADODB.Connection
        Dim rs_dados As New ADODB.Recordset

        adoconn.Open(Util.conexao)

        cmb_grupo.Items.Add("TODOS")

        Dim var_sql1 As Object
        var_sql1 = "SELECT tb_cliente.GRUPO FROM tb_cliente GROUP BY tb_cliente.GRUPO HAVING (((tb_cliente.GRUPO) Is Not Null And (tb_cliente.GRUPO)<>'')) ORDER BY tb_cliente.GRUPO"

        rs_dados.Open(var_sql1, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)

        Do While Not rs_dados.EOF
            cmb_grupo.Items.Add(rs_dados("GRUPO").Value)
            rs_dados.MoveNext()
        Loop

        rs_dados.Close()
        rs_dados = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub

    Protected Sub pesquisa_clientes()

         Dim conexaoMySQL As New MySqlConnection(Application("custobb_gd").ToString())
        Dim daMySQL As MySqlDataAdapter
        Dim dsMySQL As DataSet
        Dim strSQL As String

        gridClientes.Visible = False

        gd_clientes.Columns(0).Visible = True

        strSQL = "SELECT"
        strSQL = strSQL & " tb_cliente.CNPJ_CLI, tb_cliente.COBRANCA_AUTOM, tb_cliente.NOM_CLI, tb_cliente.PENUMPER_CLI,  tb_contas.AGENCIA, tb_contas.CONTA, tb_cliente.GRUPO, tb_cliente.ESPECIALISTA, tb_cliente.PERIODO_COBRANCA, tb_cliente.TARIFA_FIXA*100 as TARIFA_FIXA, tb_cliente.TIPO_CADASTRO_TARIFA, tb_segmento.SEGMENTO"
        strSQL = strSQL & " FROM tb_cliente "
        strSQL = strSQL & " INNER JOIN tb_segmento ON tb_segmento.SEGMENTO_ID = tb_cliente.SEGMENTO "
        strSQL = strSQL & " INNER JOIN tb_contas ON tb_contas.COD_CLIENTE = tb_cliente.CNPJ_CLI "
        strSQL = strSQL & " WHERE tb_cliente.NOM_CLI like '%" & Trim(txt_pesquisa.Text) & "%'"

        If txt_pesquisa_cnpj.Text <> "" Then
            strSQL = strSQL & " and tb_cliente.CNPJ_CLI = " & Trim(txt_pesquisa_cnpj.Text)
        End If

        If cmb_especialista.SelectedValue <> "" And cmb_especialista.SelectedValue <> "TODOS" Then
            strSQL = strSQL & " AND tb_cliente.ESPECIALISTA Like '" & cmb_especialista.SelectedValue & "'"
        End If

        If cmb_per_cobranca.SelectedValue <> "" And cmb_per_cobranca.SelectedValue <> "TODOS" Then
            strSQL = strSQL & " AND tb_cliente.PERIODO_COBRANCA Like '" & cmb_per_cobranca.SelectedValue & "'"
        End If


        If cmb_grupo.SelectedValue <> "" And cmb_grupo.SelectedValue <> "TODOS" Then
            strSQL = strSQL & " AND tb_cliente.GRUPO Like '" & cmb_grupo.SelectedValue & "'"
        End If

        strSQL = strSQL & " GROUP BY tb_cliente.CNPJ_CLI "
        strSQL = strSQL & " ORDER BY tb_cliente.CNPJ_CLI, tb_cliente.NOM_CLI"

        daMySQL = New MySqlDataAdapter(strSQL, conexaoMySQL)
        dsMySQL = New DataSet
        daMySQL.Fill(dsMySQL, "Produtos")
        gd_clientes.DataSource = dsMySQL
        gd_clientes.DataBind()

        conexaoMySQL.Open()
        conexaoMySQL.Close()
        conexaoMySQL = Nothing

        gd_clientes.Columns(0).Visible = False

        If gd_clientes.Rows.Count = 0 Then
           gridClientes.Visible =  false
        Else
           gridClientes.Visible = true
        End If

    End Sub

    Protected Sub bt_pesquisa_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt_pesquisa.Click
        pesquisa_clientes()
    End Sub

    Protected Sub OnPageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        gd_clientes.PageIndex = e.NewPageIndex
        pesquisa_clientes()
    End Sub

    Protected Sub Abrir_cliente(ByVal sender As Object, ByVal e As EventArgs)

        Dim row As GridViewRow = CType(CType(sender, LinkButton).Parent.Parent, GridViewRow)

        Response.Redirect("Pontos.aspx?cod=" & row.Cells(0).Text & "&referencia=" & Util.Retorna_Mes_vigente())

    End Sub
End Class
