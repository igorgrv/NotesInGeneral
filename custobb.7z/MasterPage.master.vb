﻿
Partial Class MasterPage
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Pesquisar_acesso()
        End If

    End Sub

    Public Sub Pesquisar_acesso()
        Dim adoconn As New ADODB.Connection
        adoconn.Open(Application("custobb").ToString())

        Dim nome As String = Right(HttpContext.Current.User.Identity.Name, 7)

        Dim rs_controle As New ADODB.Recordset
        Dim var_controle As Object
        var_controle = "SELECT * FROM tb_usuario where login ='" & nome & "'"
        'var_controle = "SELECT * FROM tb_usuario where login ='t709853'"
        rs_controle.Open(var_controle, adoconn, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockPessimistic)



        If Not rs_controle.EOF Then
            lbl_nome.Text = rs_controle.Fields("nome").Value
            Session("nome") = rs_controle.Fields("nome").Value
            Session("perfil") = rs_controle.Fields("perfil").Value
            Session("Aprovador") = rs_controle.Fields("nome_aprovador").Value
            lbl_perfil.Text = rs_controle.Fields("perfil").Value
        Else
            Response.Redirect("SemAcessoForm.aspx")
        End If

        If (rs_controle.Fields("perfil").Value = "Admin") Then
            li_usuario.Visible = True
        End If

        rs_controle.Close()
        rs_controle = Nothing

        adoconn.Close()
        adoconn = Nothing

    End Sub

End Class

