import NotificationRule from './NotificationRule';
export default NotificationRule;
