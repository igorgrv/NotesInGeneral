import React from 'react';

const Home = () => (
  <>
    <h1>NotificationRule</h1>
  </>
);

export default Home;
